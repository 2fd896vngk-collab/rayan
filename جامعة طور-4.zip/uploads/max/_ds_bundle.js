/* @ds-bundle: {"format":4,"namespace":"TawrUniversityDesignSystem_40b441","components":[{"name":"CollegeCard","sourcePath":"components/brand/CollegeCard.jsx"},{"name":"LevelBadge","sourcePath":"components/brand/LevelBadge.jsx"},{"name":"Logo","sourcePath":"components/brand/Logo.jsx"},{"name":"PatternBand","sourcePath":"components/brand/PatternBand.jsx"},{"name":"StatTile","sourcePath":"components/brand/StatTile.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"Alert","sourcePath":"components/feedback/Alert.jsx"},{"name":"ProgressBar","sourcePath":"components/feedback/ProgressBar.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/brand/CollegeCard.jsx":"b7af02b81039","components/brand/LevelBadge.jsx":"674e9452422a","components/brand/Logo.jsx":"33a34f80e15c","components/brand/PatternBand.jsx":"984b3b5e4f1e","components/brand/StatTile.jsx":"3ac4eac1ade9","components/core/Badge.jsx":"7ffb0afd92d1","components/core/Button.jsx":"d8ac36b847f3","components/core/Card.jsx":"2516d4670754","components/core/IconButton.jsx":"c21d79030d91","components/core/Tag.jsx":"7120dd8b83fd","components/feedback/Alert.jsx":"ce31102c5d9d","components/feedback/ProgressBar.jsx":"ed2bf2d0b61e","components/forms/Checkbox.jsx":"4297336b33aa","components/forms/Input.jsx":"41525a084360","components/forms/Select.jsx":"f8ce6d538e0c","components/forms/Switch.jsx":"d36263ac38a7","components/navigation/Tabs.jsx":"5b2afcbcdd02","ui_kits/website/Attendance.screen.jsx":"e476d9c81f16","ui_kits/website/Chrome.screen.jsx":"2b819891ab1c","ui_kits/website/Home.screen.jsx":"548197da0f10","ui_kits/website/Plan.screen.jsx":"0909bf170df3","ui_kits/website/Signup.screen.jsx":"2226ab211c91","ui_kits/website/app.jsx":"3b5a75e2886a","ui_kits/website/data.js":"2afa789b3088"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.TawrUniversityDesignSystem_40b441 = window.TawrUniversityDesignSystem_40b441 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/brand/LevelBadge.jsx
try { (() => {
const LEVELS = {
  diploma: {
    label: "دبلوم",
    color: "var(--level-diploma)",
    fg: "var(--tawr-navy-700)",
    n: 1
  },
  bachelor: {
    label: "بكالوريوس",
    color: "var(--level-bachelor)",
    fg: "#fff",
    n: 2
  },
  master: {
    label: "ماجستير",
    color: "var(--level-master)",
    fg: "var(--tawr-navy-700)",
    n: 3
  },
  phd: {
    label: "دكتوراه",
    color: "var(--level-phd)",
    fg: "#fff",
    n: 4
  }
};
function LevelBadge({
  level = "diploma",
  state = "open",
  showNumber,
  size = "md",
  color,
  textColor,
  numberColor
}) {
  const l = LEVELS[level] || LEVELS.diploma;
  const done = state === "passed",
    locked = state === "locked";
  const pad = size === "sm" ? "5px 12px" : "8px 16px";
  const fs = size === "sm" ? "var(--fs-caption)" : "var(--fs-body-sm)";
  return React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--space-2)",
      padding: pad,
      borderRadius: "var(--radius-pill)",
      font: `var(--fw-bold) ${fs}/1 var(--font-display)`,
      background: locked ? "var(--surface-sunken)" : color || l.color,
      color: locked ? "var(--text-muted)" : textColor || l.fg,
      border: done ? "var(--stroke) solid var(--tawr-navy-700)" : "var(--stroke) solid transparent",
      opacity: locked ? .75 : 1
    }
  }, showNumber ? React.createElement("span", {
    style: {
      width: 18,
      height: 18,
      borderRadius: "50%",
      background: locked ? "var(--tawr-navy-200)" : "rgba(255,255,255,.35)",
      display: "grid",
      placeItems: "center",
      fontSize: 11,
      fontFamily: "var(--font-mono)",
      color: numberColor || undefined
    }
  }, l.n) : null, l.label, done ? React.createElement("span", {
    style: {
      fontSize: 11,
      opacity: .8
    }
  }, "مجتاز") : null);
}
Object.assign(__ds_scope, { LevelBadge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/LevelBadge.jsx", error: String((e && e.message) || e) }); }

// components/brand/Logo.jsx
try { (() => {
/* Renders the SUPPLIED wordmark/chevron image assets. Never re-draw the mark.
   Copy assets/ into the consuming project and pass the correct relative src. */
function Logo({
  variant = "wordmark",
  src,
  height = 40,
  alt = "جامعة طور",
  style,
  ...rest
}) {
  const defaults = {
    wordmark: "assets/logo-wordmark-transparent.png",
    "wordmark-on-dark": "assets/logo-wordmark-on-navy.png",
    chevron: "assets/logo-chevron-mark.png"
  };
  return React.createElement("img", {
    src: src || defaults[variant] || defaults.wordmark,
    alt,
    style: {
      height,
      width: "auto",
      display: "block",
      ...style
    },
    ...rest
  });
}
Object.assign(__ds_scope, { Logo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Logo.jsx", error: String((e && e.message) || e) }); }

// components/brand/PatternBand.jsx
try { (() => {
/* Bottom-anchored chevron field, as it appears in the supplied banner and on the t-shirt hem. */
function PatternBand({
  src = "assets/pattern-chevrons-scatter.png",
  height = 220,
  background = "var(--tawr-navy-canvas)",
  opacity = 1,
  flip,
  children,
  style,
  ...rest
}) {
  return React.createElement("div", {
    style: {
      position: "relative",
      overflow: "hidden",
      background,
      minHeight: height,
      ...style
    },
    ...rest
  }, React.createElement("img", {
    src,
    alt: "",
    style: {
      position: "absolute",
      insetInline: 0,
      bottom: 0,
      width: "100%",
      opacity,
      transform: flip ? "scaleX(-1)" : "none",
      pointerEvents: "none"
    }
  }), React.createElement("div", {
    style: {
      position: "relative"
    }
  }, children));
}
Object.assign(__ds_scope, { PatternBand });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/PatternBand.jsx", error: String((e && e.message) || e) }); }

// components/brand/StatTile.jsx
try { (() => {
function StatTile({
  value,
  label,
  tone = "paper",
  sub,
  background,
  subColor,
  valueColor
}) {
  const tones = {
    paper: {
      bg: "var(--surface-card)",
      fg: "var(--text-strong)",
      sub: "var(--text-muted)",
      shadow: "var(--shadow-sm)"
    },
    brand: {
      bg: "var(--surface-brand)",
      fg: "#fff",
      sub: "rgba(255,255,255,.82)",
      shadow: "var(--shadow-brand)"
    },
    ink: {
      bg: "var(--surface-ink)",
      fg: "#fff",
      sub: "var(--tawr-navy-200)",
      shadow: "var(--shadow-md)"
    },
    accent: {
      bg: "var(--surface-accent)",
      fg: "var(--tawr-navy-700)",
      sub: "var(--tawr-navy-600)",
      shadow: "var(--shadow-accent)"
    }
  };
  const t = tones[tone] || tones.paper;
  return React.createElement("div", {
    style: {
      background: background || t.bg,
      color: t.fg,
      borderRadius: "var(--radius-card)",
      padding: "var(--card-pad)",
      boxShadow: t.shadow,
      display: "flex",
      flexDirection: "column",
      gap: 4
    }
  }, React.createElement("span", {
    style: {
      font: "var(--fw-extrabold) var(--fs-display-3)/1 var(--font-display)",
      color: valueColor || undefined
    }
  }, value), React.createElement("span", {
    style: {
      font: "var(--type-label)"
    }
  }, label), sub ? React.createElement("span", {
    style: {
      font: "var(--type-caption)",
      color: subColor || t.sub
    }
  }, sub) : null);
}
Object.assign(__ds_scope, { StatTile });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/StatTile.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
const TONES = {
  brand: ["var(--surface-brand-soft)", "var(--tawr-teal-800)"],
  success: ["var(--status-success-soft)", "var(--status-success)"],
  warning: ["var(--status-warning-soft)", "var(--tawr-yellow-700)"],
  danger: ["var(--status-danger-soft)", "var(--status-danger)"],
  info: ["var(--status-info-soft)", "var(--status-info)"],
  solid: ["var(--tawr-navy-600)", "#fff"]
};
function Badge({
  children,
  tone = "brand",
  dot,
  solid,
  ...rest
}) {
  const [bg, fg] = TONES[tone] || TONES.brand;
  return React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--space-2)",
      background: solid ? fg : bg,
      color: solid ? "#fff" : fg,
      borderRadius: "var(--radius-pill)",
      padding: "5px 12px",
      font: "var(--type-caption)",
      fontWeight: "var(--fw-bold)",
      whiteSpace: "nowrap"
    },
    ...rest
  }, dot ? React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: "50%",
      background: solid ? "#fff" : fg
    }
  }) : null, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
const PALETTE = {
  primary: {
    bg: "var(--tawr-teal-600)",
    bgHover: "var(--tawr-teal-700)",
    bgPress: "var(--tawr-teal-800)",
    fg: "var(--text-on-brand)",
    border: "transparent",
    shadow: "var(--shadow-brand)"
  },
  secondary: {
    bg: "var(--tawr-navy-600)",
    bgHover: "var(--tawr-navy-700)",
    bgPress: "var(--tawr-navy-800)",
    fg: "var(--text-on-ink)",
    border: "transparent",
    shadow: "var(--shadow-md)"
  },
  accent: {
    bg: "var(--tawr-yellow-500)",
    bgHover: "var(--tawr-yellow-600)",
    bgPress: "var(--tawr-yellow-700)",
    fg: "var(--text-on-accent)",
    border: "transparent",
    shadow: "var(--shadow-accent)"
  },
  danger: {
    bg: "var(--tawr-coral-500)",
    bgHover: "var(--tawr-coral-600)",
    bgPress: "var(--tawr-coral-700)",
    fg: "#fff",
    border: "transparent",
    shadow: "var(--shadow-md)"
  },
  outline: {
    bg: "transparent",
    bgHover: "var(--surface-brand-soft)",
    bgPress: "var(--tawr-teal-200)",
    fg: "var(--text-brand)",
    border: "var(--tawr-teal-600)",
    shadow: "none"
  },
  ghost: {
    bg: "transparent",
    bgHover: "var(--surface-brand-soft)",
    bgPress: "var(--tawr-teal-200)",
    fg: "var(--text-brand)",
    border: "transparent",
    shadow: "none"
  }
};
const SIZES = {
  sm: {
    h: "var(--control-h-sm)",
    px: "16px",
    fs: "var(--fs-body-sm)"
  },
  md: {
    h: "var(--control-h)",
    px: "22px",
    fs: "var(--fs-body)"
  },
  lg: {
    h: "var(--control-h-lg)",
    px: "28px",
    fs: "var(--fs-body-lg)"
  }
};
function Button({
  variant = "primary",
  size = "md",
  iconStart,
  iconEnd,
  fullWidth,
  disabled,
  children,
  onClick,
  type = "button",
  style: styleOverride,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const p = PALETTE[variant] || PALETTE.primary,
    s = SIZES[size] || SIZES.md;
  const style = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "var(--space-2)",
    height: s.h,
    padding: `0 ${s.px}`,
    width: fullWidth ? "100%" : undefined,
    font: `var(--fw-bold) ${s.fs}/1 var(--font-text)`,
    color: disabled ? "var(--text-muted)" : p.fg,
    background: disabled ? "var(--surface-sunken)" : press ? p.bgPress : hover ? p.bgHover : p.bg,
    border: `var(--stroke) solid ${disabled ? "transparent" : p.border}`,
    borderRadius: "var(--radius-control)",
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? .72 : 1,
    boxShadow: disabled || variant === "ghost" || variant === "outline" ? "none" : press ? "var(--shadow-xs)" : hover ? p.shadow : "var(--shadow-sm)",
    transform: disabled ? "none" : press ? `scale(var(--press-scale))` : hover ? "translateY(var(--hover-lift))" : "none",
    transition: "var(--transition-control)",
    whiteSpace: "nowrap",
    ...styleOverride
  };
  return React.createElement("button", {
    type,
    disabled,
    onClick,
    style,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setPress(false);
    },
    onMouseDown: () => setPress(true),
    onMouseUp: () => setPress(false),
    ...rest
  }, iconStart, children, iconEnd);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function Card({
  children,
  accent,
  interactive,
  padding = "var(--card-pad)",
  tone = "paper",
  watermark,
  style,
  onClick,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const tones = {
    paper: {
      bg: "var(--surface-card)",
      fg: "var(--text-body)"
    },
    ink: {
      bg: "var(--surface-ink)",
      fg: "var(--text-on-ink)"
    },
    brand: {
      bg: "var(--surface-brand)",
      fg: "#fff"
    },
    soft: {
      bg: "var(--surface-brand-soft)",
      fg: "var(--text-body)"
    }
  };
  const t = tones[tone] || tones.paper;
  return React.createElement("div", {
    onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      position: "relative",
      overflow: "hidden",
      background: t.bg,
      color: t.fg,
      borderRadius: "var(--radius-card)",
      padding,
      boxShadow: interactive && hover ? "var(--shadow-md)" : "var(--shadow-sm)",
      transform: interactive && hover ? "translateY(var(--hover-lift))" : "none",
      cursor: interactive ? "pointer" : undefined,
      transition: "box-shadow var(--dur-base) var(--ease-standard),transform var(--dur-base) var(--ease-standard)",
      ...style
    },
    ...rest
  }, accent ? React.createElement("span", {
    style: {
      position: "absolute",
      insetInline: 0,
      top: 0,
      height: 4,
      background: accent
    }
  }) : null, watermark ? React.createElement("img", {
    src: watermark,
    alt: "",
    style: {
      position: "absolute",
      left: -18,
      bottom: -14,
      width: 120,
      opacity: .08,
      pointerEvents: "none"
    }
  }) : null, children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
const TONES = {
  brand: {
    bg: "var(--tawr-teal-600)",
    hover: "var(--tawr-teal-700)",
    fg: "#fff"
  },
  ink: {
    bg: "var(--tawr-navy-600)",
    hover: "var(--tawr-navy-700)",
    fg: "#fff"
  },
  soft: {
    bg: "var(--surface-brand-soft)",
    hover: "var(--tawr-teal-200)",
    fg: "var(--text-brand)"
  },
  quiet: {
    bg: "transparent",
    hover: "var(--surface-sunken)",
    fg: "var(--text-body)"
  },
  glass: {
    bg: "rgba(255,255,255,.14)",
    hover: "rgba(255,255,255,.24)",
    fg: "#fff"
  }
};
const S = {
  sm: 32,
  md: 40,
  lg: 48
};
function IconButton({
  icon,
  tone = "quiet",
  size = "md",
  label,
  disabled,
  onClick,
  style: styleOverride,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const t = TONES[tone] || TONES.quiet,
    d = S[size] || S.md;
  return React.createElement("button", {
    type: "button",
    "aria-label": label,
    disabled,
    onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setPress(false);
    },
    onMouseDown: () => setPress(true),
    onMouseUp: () => setPress(false),
    style: {
      width: d,
      height: d,
      display: "inline-grid",
      placeItems: "center",
      borderRadius: "var(--radius-pill)",
      border: "none",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? .4 : 1,
      background: hover && !disabled ? t.hover : t.bg,
      color: t.fg,
      transform: press ? "scale(var(--press-scale))" : "none",
      transition: "var(--transition-control)",
      ...styleOverride
    },
    ...rest
  }, icon);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function Tag({
  children,
  color = "var(--tawr-teal-600)",
  selected,
  onClick,
  onRemove,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const clickable = !!onClick;
  return React.createElement("span", {
    onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--space-2)",
      padding: "7px 14px",
      borderRadius: "var(--radius-chip)",
      font: "var(--type-label)",
      color: selected ? "#fff" : color,
      background: selected ? color : hover && clickable ? "var(--surface-brand-soft)" : "transparent",
      border: `var(--stroke) solid ${selected ? color : "var(--border-default)"}`,
      cursor: clickable ? "pointer" : "default",
      transition: "var(--transition-control)"
    },
    ...rest
  }, children, onRemove ? React.createElement("span", {
    onClick: e => {
      e.stopPropagation();
      onRemove();
    },
    style: {
      cursor: "pointer",
      opacity: .65,
      fontSize: 14,
      lineHeight: 1
    }
  }, "×") : null);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Alert.jsx
try { (() => {
const TONES = {
  info: ["var(--status-info-soft)", "var(--status-info)"],
  success: ["var(--status-success-soft)", "var(--status-success)"],
  warning: ["var(--status-warning-soft)", "var(--tawr-yellow-700)"],
  danger: ["var(--status-danger-soft)", "var(--status-danger)"]
};
function Alert({
  tone = "info",
  title,
  children,
  icon,
  onClose
}) {
  const [bg, fg] = TONES[tone] || TONES.info;
  return React.createElement("div", {
    role: "status",
    style: {
      display: "flex",
      gap: "var(--space-3)",
      background: bg,
      borderRadius: "var(--radius-md)",
      padding: "14px 16px",
      color: "var(--text-body)"
    }
  }, icon ? React.createElement("span", {
    style: {
      color: fg,
      display: "grid",
      flex: "0 0 auto",
      marginTop: 1
    }
  }, icon) : null, React.createElement("div", {
    style: {
      flex: 1,
      display: "flex",
      flexDirection: "column",
      gap: 4
    }
  }, title ? React.createElement("strong", {
    style: {
      font: "var(--type-body-strong)",
      color: fg
    }
  }, title) : null, children ? React.createElement("span", {
    style: {
      font: "var(--type-body)",
      fontSize: "var(--fs-body-sm)"
    }
  }, children) : null), onClose ? React.createElement("button", {
    onClick: onClose,
    "aria-label": "إغلاق",
    style: {
      border: "none",
      background: "transparent",
      cursor: "pointer",
      color: fg,
      fontSize: 16,
      lineHeight: 1
    }
  }, "×") : null);
}
Object.assign(__ds_scope, { Alert });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Alert.jsx", error: String((e && e.message) || e) }); }

// components/feedback/ProgressBar.jsx
try { (() => {
function ProgressBar({
  value = 0,
  max = 100,
  color = "var(--tawr-teal-600)",
  height = 10,
  label,
  showValue,
  segments
}) {
  const pct = Math.max(0, Math.min(100, value / max * 100));
  const track = React.createElement("div", {
    style: {
      background: "var(--surface-sunken)",
      borderRadius: "var(--radius-pill)",
      height,
      overflow: "hidden",
      display: "flex",
      flexDirection: "row-reverse"
    }
  }, segments ? segments.map((s, i) => React.createElement("div", {
    key: i,
    style: {
      width: `${s.value / max * 100}%`,
      background: s.color,
      transition: `width var(--dur-slow) var(--ease-rise)`
    }
  })) : React.createElement("div", {
    style: {
      width: `${pct}%`,
      background: color,
      borderRadius: "var(--radius-pill)",
      transition: `width var(--dur-slow) var(--ease-rise)`
    }
  }));
  if (!label && !showValue) return track;
  return React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-2)",
      width: "100%"
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "baseline"
    }
  }, label ? React.createElement("span", {
    style: {
      font: "var(--type-label)",
      color: "var(--text-strong)"
    }
  }, label) : null, showValue ? React.createElement("span", {
    style: {
      font: "var(--type-caption)",
      color: "var(--text-muted)",
      fontFamily: "var(--font-mono)"
    }
  }, `${Math.round(pct)}%`) : null), track);
}
Object.assign(__ds_scope, { ProgressBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/ProgressBar.jsx", error: String((e && e.message) || e) }); }

// components/brand/CollegeCard.jsx
try { (() => {
function CollegeCard({
  name,
  color = "var(--faculty-sharia)",
  levelsPassed = 0,
  levelsTotal = 4,
  description,
  icon,
  watermark,
  onClick,
  status
}) {
  return React.createElement(__ds_scope.Card, {
    accent: color,
    interactive: !!onClick,
    onClick,
    watermark,
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-3)"
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-3)"
    }
  }, icon ? React.createElement("span", {
    style: {
      width: 44,
      height: 44,
      borderRadius: "var(--radius-md)",
      background: color,
      color: "#fff",
      display: "grid",
      placeItems: "center",
      flex: "0 0 auto"
    }
  }, icon) : null, React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, React.createElement("h3", {
    style: {
      font: "var(--type-card-title)",
      color: "var(--text-strong)",
      margin: 0
    }
  }, name)), status ? React.createElement(__ds_scope.Badge, {
    tone: levelsPassed >= levelsTotal ? "success" : "info"
  }, status) : null), description ? React.createElement("p", {
    style: {
      font: "var(--type-body)",
      color: "var(--text-body)",
      margin: 0
    }
  }, description) : null, React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-2)",
      marginTop: "auto"
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      font: "var(--type-caption)",
      color: "var(--text-muted)"
    }
  }, React.createElement("span", null, "المستويات المجتازة"), React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)"
    }
  }, `${levelsPassed}/${levelsTotal}`)), React.createElement(__ds_scope.ProgressBar, {
    value: levelsPassed,
    max: levelsTotal,
    color,
    height: 8
  })));
}
Object.assign(__ds_scope, { CollegeCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/CollegeCard.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function Checkbox({
  label,
  checked,
  onChange,
  disabled,
  description,
  ...rest
}) {
  return React.createElement("label", {
    style: {
      display: "flex",
      gap: "var(--space-3)",
      alignItems: "flex-start",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? .4 : 1
    }
  }, React.createElement("span", {
    style: {
      position: "relative",
      flex: "0 0 auto",
      width: 22,
      height: 22,
      marginTop: 1,
      borderRadius: "var(--radius-xs)",
      border: `var(--stroke) solid ${checked ? "var(--tawr-teal-600)" : "var(--border-default)"}`,
      background: checked ? "var(--tawr-teal-600)" : "var(--surface-card)",
      boxShadow: checked ? "none" : "var(--shadow-inset)",
      transition: "var(--transition-control)"
    }
  }, React.createElement("input", {
    type: "checkbox",
    checked: !!checked,
    onChange,
    disabled,
    style: {
      position: "absolute",
      inset: 0,
      opacity: 0,
      margin: 0,
      cursor: "inherit",
      width: "100%",
      height: "100%"
    },
    ...rest
  }), checked ? React.createElement("span", {
    style: {
      position: "absolute",
      top: 4,
      left: 6,
      width: 8,
      height: 4,
      borderInline: "none",
      borderTop: "none",
      borderInlineStart: "2px solid #fff",
      borderBottom: "2px solid #fff",
      transform: "rotate(-45deg)"
    }
  }) : null), React.createElement("span", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 2
    }
  }, React.createElement("span", {
    style: {
      font: "var(--type-body-strong)",
      color: "var(--text-strong)"
    }
  }, label), description ? React.createElement("span", {
    style: {
      font: "var(--type-caption)",
      color: "var(--text-muted)"
    }
  }, description) : null));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function Input({
  label,
  hint,
  error,
  icon,
  type = "text",
  value,
  onChange,
  placeholder,
  disabled,
  id,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const inputId = id || React.useId();
  const borderColor = error ? "var(--status-danger)" : focus ? "var(--tawr-teal-600)" : "var(--border-default)";
  return React.createElement("label", {
    htmlFor: inputId,
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-2)",
      width: "100%",
      minWidth: 0
    }
  }, label ? React.createElement("span", {
    style: {
      font: "var(--type-label)",
      color: "var(--text-strong)"
    }
  }, label) : null, React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-2)",
      minWidth: 0,
      height: "var(--control-h)",
      padding: "0 14px",
      background: disabled ? "var(--surface-sunken)" : "var(--surface-card)",
      border: `var(--stroke) solid ${borderColor}`,
      borderRadius: "var(--radius-input)",
      boxShadow: focus ? "none" : "var(--shadow-inset)",
      transition: "border-color var(--dur-fast) var(--ease-standard)"
    }
  }, icon ? React.createElement("span", {
    style: {
      color: "var(--text-muted)",
      display: "grid"
    }
  }, icon) : null, React.createElement("input", {
    id: inputId,
    type,
    value,
    onChange,
    placeholder,
    disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      border: "none",
      outline: "none",
      background: "transparent",
      font: "var(--type-body)",
      color: "var(--text-strong)",
      minWidth: 0
    },
    ...rest
  })), error ? React.createElement("span", {
    style: {
      font: "var(--type-caption)",
      color: "var(--status-danger)"
    }
  }, error) : hint ? React.createElement("span", {
    style: {
      font: "var(--type-caption)",
      color: "var(--text-muted)"
    }
  }, hint) : null);
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function Select({
  label,
  hint,
  options = [],
  value,
  onChange,
  placeholder,
  disabled,
  id,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const selectId = id || React.useId();
  return React.createElement("label", {
    htmlFor: selectId,
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-2)",
      width: "100%",
      minWidth: 0
    }
  }, label ? React.createElement("span", {
    style: {
      font: "var(--type-label)",
      color: "var(--text-strong)"
    }
  }, label) : null, React.createElement("span", {
    style: {
      position: "relative",
      display: "block"
    }
  }, React.createElement("select", {
    id: selectId,
    value,
    onChange,
    disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      width: "100%",
      height: "var(--control-h)",
      padding: "0 14px",
      appearance: "none",
      background: disabled ? "var(--surface-sunken)" : "var(--surface-card)",
      border: `var(--stroke) solid ${focus ? "var(--tawr-teal-600)" : "var(--border-default)"}`,
      borderRadius: "var(--radius-input)",
      font: "var(--type-body)",
      color: "var(--text-strong)",
      cursor: disabled ? "not-allowed" : "pointer"
    },
    ...rest
  }, placeholder ? React.createElement("option", {
    value: "",
    disabled: true
  }, placeholder) : null, options.map(o => React.createElement("option", {
    key: o.value,
    value: o.value
  }, o.label))), React.createElement("svg", {
    width: 18,
    height: 18,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 2,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true",
    style: {
      position: "absolute",
      left: 14,
      top: "50%",
      transform: "translateY(-50%)",
      pointerEvents: "none",
      color: "var(--text-muted)"
    }
  }, React.createElement("path", {
    d: "m6 9 6 6 6-6"
  }))), hint ? React.createElement("span", {
    style: {
      font: "var(--type-caption)",
      color: "var(--text-muted)"
    }
  }, hint) : null);
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function Switch({
  label,
  checked,
  onChange,
  disabled,
  ...rest
}) {
  return React.createElement("label", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--space-3)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? .4 : 1
    }
  }, React.createElement("span", {
    role: "switch",
    "aria-checked": !!checked,
    onClick: () => !disabled && onChange && onChange(!checked),
    style: {
      width: 46,
      height: 26,
      borderRadius: "var(--radius-pill)",
      padding: 3,
      background: checked ? "var(--tawr-teal-600)" : "var(--tawr-navy-200)",
      display: "flex",
      justifyContent: checked ? "flex-start" : "flex-end",
      transition: "background-color var(--dur-fast) var(--ease-standard)"
    },
    ...rest
  }, React.createElement("span", {
    style: {
      width: 20,
      height: 20,
      borderRadius: "50%",
      background: "#fff",
      boxShadow: "var(--shadow-xs)",
      transition: "transform var(--dur-fast) var(--ease-standard)"
    }
  })), label ? React.createElement("span", {
    style: {
      font: "var(--type-body-strong)",
      color: "var(--text-strong)"
    }
  }, label) : null);
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function Tabs({
  items = [],
  value,
  onChange,
  variant = "pill"
}) {
  const isPill = variant === "pill";
  return React.createElement("div", {
    role: "tablist",
    style: {
      display: "flex",
      gap: isPill ? "var(--space-2)" : "var(--space-6)",
      background: isPill ? "var(--surface-sunken)" : "transparent",
      padding: isPill ? "5px" : 0,
      borderRadius: "var(--radius-pill)",
      borderBottom: isPill ? "none" : "1px solid var(--border-subtle)",
      width: "fit-content",
      maxWidth: "100%"
    }
  }, items.map(it => {
    const active = it.value === value;
    return React.createElement("button", {
      key: it.value,
      role: "tab",
      "aria-selected": active,
      onClick: () => onChange && onChange(it.value),
      style: {
        border: "none",
        cursor: "pointer",
        whiteSpace: "nowrap",
        font: `${active ? "var(--fw-bold)" : "var(--fw-medium)"} var(--fs-body-sm)/1 var(--font-text)`,
        color: active ? isPill ? "var(--text-on-brand)" : "var(--text-brand)" : "var(--text-muted)",
        background: isPill ? active ? "var(--tawr-teal-600)" : "transparent" : "transparent",
        borderRadius: "var(--radius-pill)",
        padding: isPill ? "10px 18px" : "0 0 12px",
        borderBottom: isPill ? "none" : `var(--stroke-thick) solid ${active ? "var(--tawr-teal-600)" : "transparent"}`,
        transition: "var(--transition-control)"
      }
    }, it.label, it.count != null ? React.createElement("span", {
      style: {
        marginInlineStart: 6,
        opacity: .7
      }
    }, it.count) : null);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Attendance.screen.jsx
try { (() => {
const {
  Button,
  Input,
  Select,
  Badge,
  Tag,
  Alert,
  ProgressBar,
  IconButton
} = window.TawrUniversityDesignSystem_40b441;

/* خانة التحضير: المشرف يضيف برامج، ويحضّر الطلاب في كل برنامج. */
function AttendanceScreen() {
  const {
    colleges
  } = window.TAWR;
  const [programs, setPrograms] = React.useState([{
    id: 1,
    name: "حلقة القرآن الأسبوعية",
    college: "quran",
    day: "الأحد",
    time: "17:00",
    students: [{
      n: "عبدالله المطيري",
      s: "present"
    }, {
      n: "سعد الحربي",
      s: "present"
    }, {
      n: "محمد العتيبي",
      s: "late"
    }, {
      n: "يوسف الشمري",
      s: "absent"
    }, {
      n: "تركي القحطاني",
      s: "present"
    }]
  }, {
    id: 2,
    name: "ورشة البرمجة",
    college: "tech",
    day: "الثلاثاء",
    time: "19:00",
    students: [{
      n: "عبدالله المطيري",
      s: "present"
    }, {
      n: "سعد الحربي",
      s: "absent"
    }, {
      n: "محمد العتيبي",
      s: "present"
    }, {
      n: "يوسف الشمري",
      s: "present"
    }]
  }, {
    id: 3,
    name: "لقاء القيادة (اختياري)",
    college: "skills",
    day: "الخميس",
    time: "18:30",
    students: [{
      n: "سعد الحربي",
      s: "present"
    }, {
      n: "تركي القحطاني",
      s: "late"
    }]
  }]);
  const [activeId, setActiveId] = React.useState(1);
  const [adding, setAdding] = React.useState(false);
  const [form, setForm] = React.useState({
    name: "",
    college: "quran",
    day: "الأحد",
    time: "17:00"
  });
  const active = programs.find(p => p.id === activeId) || programs[0];
  const colorOf = id => (colleges.find(c => c.id === id) || {}).color || "var(--tawr-teal-600)";
  const nameOf = id => (colleges.find(c => c.id === id) || {}).name || "";
  const setState = (i, s) => setPrograms(ps => ps.map(p => p.id !== active.id ? p : {
    ...p,
    students: p.students.map((st, idx) => idx === i ? {
      ...st,
      s
    } : st)
  }));
  const addProgram = () => {
    if (!form.name.trim()) return;
    const id = Math.max(0, ...programs.map(p => p.id)) + 1;
    setPrograms(ps => [...ps, {
      ...form,
      id,
      name: form.name.trim(),
      students: [{
        n: "عبدالله المطيري",
        s: "none"
      }, {
        n: "سعد الحربي",
        s: "none"
      }, {
        n: "محمد العتيبي",
        s: "none"
      }, {
        n: "يوسف الشمري",
        s: "none"
      }]
    }]);
    setActiveId(id);
    setAdding(false);
    setForm({
      name: "",
      college: "quran",
      day: "الأحد",
      time: "17:00"
    });
  };
  const counts = active.students.reduce((a, s) => ({
    ...a,
    [s.s]: (a[s.s] || 0) + 1
  }), {});
  const present = counts.present || 0,
    late = counts.late || 0,
    absent = counts.absent || 0;
  const marked = present + late + absent;
  const STATES = [["present", "حاضر", "var(--tawr-teal-600)"], ["late", "متأخر", "var(--tawr-yellow-500)"], ["absent", "غائب", "var(--tawr-coral-500)"]];
  const dark = {
    "--text-strong": "var(--text-on-canvas)",
    "--surface-card": "rgba(0,0,0,.2)",
    "--border-default": "var(--border-canvas)",
    "--text-muted": "var(--text-on-canvas-muted)"
  };
  return /*#__PURE__*/React.createElement(CanvasPage, null, /*#__PURE__*/React.createElement(CanvasBackdrop, {
    opacity: .55,
    width: 330
  }), /*#__PURE__*/React.createElement("main", {
    style: {
      position: "relative",
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "var(--space-16) var(--container-pad) var(--space-20)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-end",
      gap: "var(--space-8)",
      marginBottom: "var(--space-6)"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      color: "var(--text-on-canvas)",
      marginBottom: "var(--space-2)"
    }
  }, "\u0627\u0644\u062A\u062D\u0636\u064A\u0631"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--type-body)",
      color: "var(--text-on-canvas-muted)",
      maxWidth: "58ch",
      margin: 0
    }
  }, "\u064A\u0636\u064A\u0641 \u0627\u0644\u0645\u0634\u0631\u0641 \u0627\u0644\u0628\u0631\u0627\u0645\u062C\u060C \u062B\u0645 \u064A\u062D\u0636\u0651\u0631 \u0627\u0644\u0637\u0644\u0627\u0628 \u0641\u064A \u0643\u0644 \u0628\u0631\u0646\u0627\u0645\u062C. \u0627\u0644\u0628\u0631\u0627\u0645\u062C \u0627\u0644\u0627\u062E\u062A\u064A\u0627\u0631\u064A\u0629 \u062A\u064F\u0639\u0644\u064E\u0651\u0645 \u0628\u0630\u0644\u0643 \u0635\u0631\u0627\u062D\u0629\u064B.")), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    onClick: () => setAdding(a => !a),
    iconStart: /*#__PURE__*/React.createElement("i", {
      "data-lucide": adding ? "x" : "plus"
    })
  }, adding ? "إلغاء" : "أضف برنامجًا")), adding && /*#__PURE__*/React.createElement(DarkCard, {
    padding: "var(--space-6)",
    strong: true,
    style: {
      ...dark,
      marginBottom: "var(--space-6)"
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      color: "var(--text-on-canvas)",
      marginBottom: "var(--space-4)"
    }
  }, "\u0628\u0631\u0646\u0627\u0645\u062C \u062C\u062F\u064A\u062F"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "2fr 1.2fr 1fr 1fr auto",
      gap: "var(--space-3)",
      alignItems: "end"
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "\u0627\u0633\u0645 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C",
    placeholder: "\u0645\u062B\u0627\u0644: \u062D\u0644\u0642\u0629 \u0627\u0644\u0642\u0631\u0622\u0646 \u0627\u0644\u0623\u0633\u0628\u0648\u0639\u064A\u0629",
    value: form.name,
    onChange: e => setForm({
      ...form,
      name: e.target.value
    }),
    icon: /*#__PURE__*/React.createElement("i", {
      "data-lucide": "calendar-plus"
    })
  }), /*#__PURE__*/React.createElement(Select, {
    label: "\u0627\u0644\u0643\u0644\u064A\u0629",
    value: form.college,
    onChange: e => setForm({
      ...form,
      college: e.target.value
    }),
    options: colleges.map(c => ({
      value: c.id,
      label: c.name
    }))
  }), /*#__PURE__*/React.createElement(Select, {
    label: "\u0627\u0644\u064A\u0648\u0645",
    value: form.day,
    onChange: e => setForm({
      ...form,
      day: e.target.value
    }),
    options: ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس"].map(d => ({
      value: d,
      label: d
    }))
  }), /*#__PURE__*/React.createElement(Input, {
    label: "\u0627\u0644\u0648\u0642\u062A",
    type: "time",
    value: form.time,
    onChange: e => setForm({
      ...form,
      time: e.target.value
    })
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "accent",
    onClick: addProgram
  }, "\u0623\u0636\u0641"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1.9fr",
      gap: "var(--gutter)",
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement(DarkCard, {
    padding: "var(--space-5)"
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      color: "var(--text-on-canvas)",
      marginBottom: "var(--space-4)"
    }
  }, "\u0627\u0644\u0628\u0631\u0627\u0645\u062C"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-2)"
    }
  }, programs.map(p => {
    const on = p.id === active.id;
    return /*#__PURE__*/React.createElement("button", {
      key: p.id,
      onClick: () => setActiveId(p.id),
      style: {
        textAlign: "start",
        cursor: "pointer",
        border: on ? "var(--stroke) solid " + colorOf(p.college) : "1px solid var(--border-canvas)",
        background: on ? "rgba(255,255,255,.1)" : "transparent",
        borderRadius: "var(--radius-md)",
        padding: "var(--space-3) var(--space-4)",
        display: "flex",
        flexDirection: "column",
        gap: 4,
        transition: "var(--transition-control)"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: "var(--space-2)"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 8,
        height: 8,
        borderRadius: "50%",
        background: colorOf(p.college),
        flex: "0 0 auto"
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        font: "var(--type-body-strong)",
        color: "var(--text-on-canvas)"
      }
    }, p.name)), /*#__PURE__*/React.createElement("span", {
      style: {
        font: "var(--type-caption)",
        color: "var(--text-on-canvas-muted)"
      }
    }, nameOf(p.college), " \xB7 ", p.day, " ", p.time, " \xB7 ", p.students.length, " \u0637\u0627\u0644\u0628\u064B\u0627"));
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--gutter)"
    }
  }, /*#__PURE__*/React.createElement(DarkCard, {
    accent: colorOf(active.college),
    padding: "var(--space-6)"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-start",
      gap: "var(--space-4)",
      marginBottom: "var(--space-5)"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: "var(--fs-title-2)",
      color: "var(--text-on-canvas)"
    }
  }, active.name), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--type-body)",
      color: "var(--text-on-canvas-muted)",
      margin: "4px 0 0"
    }
  }, nameOf(active.college), " \xB7 ", active.day, " \xB7 ", active.time)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-2)"
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "success"
  }, "\u062D\u0627\u0636\u0631 ", present), /*#__PURE__*/React.createElement(Badge, {
    tone: "warning"
  }, "\u0645\u062A\u0623\u062E\u0631 ", late), /*#__PURE__*/React.createElement(Badge, {
    tone: "danger"
  }, "\u063A\u0627\u0626\u0628 ", absent))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: "var(--space-5)"
    }
  }, /*#__PURE__*/React.createElement(ProgressBar, {
    label: "\u0646\u0633\u0628\u0629 \u0627\u0644\u062A\u062D\u0636\u064A\u0631",
    value: marked,
    max: active.students.length,
    showValue: true,
    color: colorOf(active.college)
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-2)"
    }
  }, active.students.map((st, i) => /*#__PURE__*/React.createElement("div", {
    key: st.n,
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-3)",
      background: "rgba(0,0,0,.16)",
      borderRadius: "var(--radius-md)",
      padding: "var(--space-3) var(--space-4)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 34,
      height: 34,
      borderRadius: "50%",
      background: "rgba(255,255,255,.1)",
      display: "grid",
      placeItems: "center",
      font: "var(--type-label)",
      color: "var(--text-on-canvas)",
      flex: "0 0 auto"
    }
  }, st.n.slice(0, 1)), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      font: "var(--type-body-strong)",
      color: "var(--text-on-canvas)"
    }
  }, st.n), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      gap: "var(--space-2)"
    }
  }, STATES.map(([key, label, color]) => {
    const on = st.s === key;
    return /*#__PURE__*/React.createElement("button", {
      key: key,
      onClick: () => setState(i, key),
      style: {
        cursor: "pointer",
        borderRadius: "var(--radius-pill)",
        padding: "6px 14px",
        font: "var(--type-label)",
        whiteSpace: "nowrap",
        border: "var(--stroke) solid " + (on ? color : "var(--border-canvas)"),
        background: on ? color : "transparent",
        color: on ? key === "late" ? "var(--tawr-navy-700)" : "#fff" : "var(--text-on-canvas-muted)",
        transition: "var(--transition-control)"
      }
    }, label);
  })))))), marked < active.students.length && /*#__PURE__*/React.createElement(Alert, {
    tone: "warning",
    title: "\u0627\u0644\u062A\u062D\u0636\u064A\u0631 \u063A\u064A\u0631 \u0645\u0643\u062A\u0645\u0644",
    icon: /*#__PURE__*/React.createElement("i", {
      "data-lucide": "triangle-alert"
    })
  }, "\u0628\u0642\u064A ", active.students.length - marked, " \u0637\u0627\u0644\u0628\u064B\u0627 \u062F\u0648\u0646 \u062A\u062D\u0636\u064A\u0631 \u0641\u064A \u0647\u0630\u0627 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062C.")))));
}
Object.assign(window, {
  AttendanceScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Attendance.screen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Chrome.screen.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  Button,
  IconButton,
  Logo
} = window.TawrUniversityDesignSystem_40b441;

/* Every surface sits on the brand's navy canvas with the chevron field behind it. */
function CanvasBackdrop({
  opacity = 1,
  width = 470
}) {
  return /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      bottom: 0,
      width,
      opacity,
      pointerEvents: "none",
      backgroundImage: "url('../../assets/pattern-chevrons-scatter.png')",
      backgroundSize: width + "px auto",
      backgroundRepeat: "repeat-y",
      backgroundPosition: "left top",
      maskImage: "linear-gradient(to right,#000 0%,#000 55%,transparent 100%)",
      WebkitMaskImage: "linear-gradient(to right,#000 0%,#000 55%,transparent 100%)"
    }
  });
}
function SiteHeader({
  route,
  go
}) {
  const nav = [["home", "الرئيسية"], ["plan", "الخطة"], ["attendance", "التحضير"], ["signup", "تسجيل الدخول"]];
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: "sticky",
      top: 0,
      zIndex: 20,
      background: "rgba(30,53,64,.9)",
      backdropFilter: "var(--blur-glass)",
      WebkitBackdropFilter: "var(--blur-glass)",
      borderBottom: "1px solid var(--border-canvas)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "0 var(--container-pad)",
      height: 84,
      display: "flex",
      alignItems: "center",
      gap: "var(--space-8)"
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#home",
    onClick: e => {
      e.preventDefault();
      go("home");
    },
    style: {
      border: "none",
      display: "flex",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    src: "../../assets/logo-wordmark-transparent.png",
    height: 52
  })), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "flex",
      gap: "var(--space-6)",
      flex: 1
    }
  }, nav.map(([k, l]) => /*#__PURE__*/React.createElement("a", {
    key: k,
    href: "#" + k,
    onClick: e => {
      e.preventDefault();
      go(k);
    },
    style: {
      border: "none",
      font: route === k ? "var(--fw-bold) var(--fs-body-sm)/1 var(--font-text)" : "var(--fw-medium) var(--fs-body-sm)/1 var(--font-text)",
      color: route === k ? "var(--tawr-teal-500)" : "var(--text-on-canvas-muted)",
      paddingBottom: 4,
      borderBottom: route === k ? "var(--stroke) solid var(--tawr-teal-500)" : "var(--stroke) solid transparent"
    }
  }, l))), /*#__PURE__*/React.createElement(IconButton, {
    tone: "glass",
    label: "\u0628\u062D\u062B",
    icon: /*#__PURE__*/React.createElement("i", {
      "data-lucide": "search"
    })
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm",
    onClick: () => go("signup"),
    style: {
      backgroundColor: "#FACB62"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "#26404D"
    }
  }, "\u0627\u0628\u062F\u0623 \u0627\u0644\u062A\u0633\u062C\u064A\u0644"))));
}
function SiteFooter() {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      position: "relative",
      overflow: "hidden",
      background: "var(--surface-canvas)",
      borderTop: "1px solid var(--border-canvas)",
      color: "var(--text-on-canvas-muted)",
      padding: "var(--space-16) 0 var(--space-8)"
    }
  }, /*#__PURE__*/React.createElement(CanvasBackdrop, {
    opacity: .45,
    width: 380
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "0 var(--container-pad)",
      display: "grid",
      gridTemplateColumns: "1.4fr 1fr 1fr",
      gap: "var(--space-12)"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Logo, {
    src: "../../assets/logo-wordmark-transparent.png",
    height: 64
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--type-body)",
      marginTop: "var(--space-5)",
      maxWidth: "38ch"
    }
  }, "\u062C\u0627\u0645\u0639\u0629 \u062A\u0639\u0644\u064A\u0645\u064A\u0629 \u062A\u0646\u0627\u0641\u0633\u064A\u0629 \u062A\u062A\u0643\u0648\u0651\u0646 \u0645\u0646 \u0639\u062F\u0629 \u0643\u0644\u064A\u0627\u062A\u060C \u064A\u062A\u062F\u0631\u0651\u062C \u0627\u0644\u0637\u0627\u0644\u0628 \u0641\u064A\u0647\u0627 \u0639\u0628\u0631 \u062F\u0631\u062C\u0627\u062A \u0623\u0643\u0627\u062F\u064A\u0645\u064A\u0629: \u0627\u0644\u062F\u0628\u0644\u0648\u0645\u060C \u0627\u0644\u0628\u0643\u0627\u0644\u0648\u0631\u064A\u0648\u0633\u060C \u0627\u0644\u0645\u0627\u062C\u0633\u062A\u064A\u0631\u060C \u0648\u0627\u0644\u062F\u0643\u062A\u0648\u0631\u0627\u0647")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h4", {
    style: {
      color: "var(--text-on-canvas)",
      font: "var(--type-label)",
      marginBottom: "var(--space-3)"
    }
  }, "\u0627\u0644\u0643\u0644\u064A\u0627\u062A"), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: "none",
      padding: 0,
      margin: 0,
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-2)",
      fontSize: "var(--fs-body-sm)"
    }
  }, window.TAWR.colleges.map(c => /*#__PURE__*/React.createElement("li", {
    key: c.id
  }, c.name)))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h4", {
    style: {
      color: "var(--text-on-canvas)",
      font: "var(--type-label)",
      marginBottom: "var(--space-3)"
    }
  }, "\u0627\u0644\u0645\u0633\u062A\u0648\u064A\u0627\u062A"), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: "none",
      padding: 0,
      margin: 0,
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-2)",
      fontSize: "var(--fs-body-sm)"
    }
  }, window.TAWR.levels.map(l => /*#__PURE__*/React.createElement("li", {
    key: l.key
  }, l.label))))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      maxWidth: "var(--container-max)",
      margin: "var(--space-10) auto 0",
      padding: "var(--space-6) var(--container-pad) 0",
      borderTop: "1px solid var(--border-canvas)",
      display: "flex",
      justifyContent: "space-between",
      fontSize: "var(--fs-caption)"
    }
  }, /*#__PURE__*/React.createElement("span", null, "\u062C\u0627\u0645\u0639\u0629 \u0637\u0648\u0631 \u2014 \u062C\u0645\u064A\u0639 \u0627\u0644\u062D\u0642\u0648\u0642 \u0645\u062D\u0641\u0648\u0638\u0629"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--tawr-teal-500)",
      fontWeight: "var(--fw-bold)"
    }
  })));
}

/* Shared page shell: navy canvas + chevron field, used by every screen. */
function CanvasPage({
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      background: "var(--surface-canvas)",
      minHeight: "100%",
      overflow: "hidden"
    }
  }, children);
}
function DarkCard({
  children,
  accent,
  padding = "var(--card-pad)",
  strong,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      position: "relative",
      overflow: "hidden",
      background: strong ? "var(--surface-canvas-card-strong)" : "var(--surface-canvas-card)",
      border: "1px solid var(--border-canvas)",
      borderRadius: "var(--radius-card)",
      padding,
      backdropFilter: "blur(6px)",
      WebkitBackdropFilter: "blur(6px)",
      ...style
    }
  }, rest), accent && /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      insetInline: 0,
      top: 0,
      height: 4,
      background: accent
    }
  }), children);
}
function SectionHead({
  title,
  sub,
  action
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-end",
      gap: "var(--space-8)",
      marginBottom: "var(--space-8)"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      color: "var(--text-on-canvas)"
    }
  }, title), sub && /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--type-body)",
      color: "var(--text-on-canvas-muted)",
      margin: "var(--space-2) 0 0",
      maxWidth: "56ch"
    }
  }, sub)), action);
}
Object.assign(window, {
  SiteHeader,
  SiteFooter,
  CanvasPage,
  CanvasBackdrop,
  DarkCard,
  SectionHead
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Chrome.screen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Home.screen.jsx
try { (() => {
const {
  Button,
  StatTile,
  ProgressBar,
  Badge,
  LevelBadge,
  Logo
} = window.TawrUniversityDesignSystem_40b441;
function Hero({
  go
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      position: "relative",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement(CanvasBackdrop, null), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "var(--space-12) var(--container-pad) var(--space-20)",
      display: "grid",
      gridTemplateColumns: "1.05fr .95fr",
      gap: "var(--space-12)",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      display: "flex",
      alignItems: "flex-end",
      gap: "var(--space-3)",
      font: "var(--fw-extrabold) 64px/1 var(--font-display)",
      color: "var(--text-on-canvas)",
      margin: "0 0 var(--space-5)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      lineHeight: 1
    }
  }, "\u062C\u0627\u0645\u0639\u0629"), /*#__PURE__*/React.createElement(Logo, {
    src: "../../assets/logo-wordmark-transparent.png",
    height: 104,
    alt: "\u0637\u0648\u0651\u0631",
    style: {
      marginBottom: -14
    }
  })), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--fs-body)/1.75 var(--font-text)",
      color: "var(--text-on-canvas-muted)",
      maxWidth: "52ch",
      margin: "var(--space-6) 0 var(--space-10)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "#FFFFFF"
    }
  }, "\u062C\u0627\u0645\u0639\u0629 \u062A\u0639\u0644\u064A\u0645\u064A\u0629 \u062A\u0646\u0627\u0641\u0633\u064A\u0629 \u062A\u062A\u0643\u0648\u0651\u0646 \u0645\u0646 \u0639\u062F\u0629 \u0643\u0644\u064A\u0627\u062A\u060C \u064A\u062A\u062F\u0631\u0651\u062C \u0627\u0644\u0637\u0627\u0644\u0628 \u0641\u064A\u0647\u0627 \u0639\u0628\u0631 \u062F\u0631\u062C\u0627\u062A \u0623\u0643\u0627\u062F\u064A\u0645\u064A\u0629: \u0627\u0644\u062F\u0628\u0644\u0648\u0645\u060C \u0627\u0644\u0628\u0643\u0627\u0644\u0648\u0631\u064A\u0648\u0633\u060C \u0627\u0644\u0645\u0627\u062C\u0633\u062A\u064A\u0631\u060C \u0648\u0627\u0644\u062F\u0643\u062A\u0648\u0631\u0627\u0647")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-3)"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    variant: "primary",
    onClick: () => go("signup"),
    style: {
      backgroundColor: "#FACB62"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "#2F4D5B"
    }
  }, "\u0627\u0628\u062F\u0623 \u0627\u0644\u062A\u0633\u062C\u064A\u0644")), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    variant: "accent",
    onClick: () => go("plan"),
    style: {
      backgroundColor: "#EE7C7D"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "#FFFFFF"
    }
  }, "\u0627\u0637\u0651\u0644\u0639 \u0639\u0644\u0649 \u0627\u0644\u062E\u0637\u0629")))), /*#__PURE__*/React.createElement("div", null)));
}
function CollegeTile({
  c,
  go,
  enrolled
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onClick: enrolled ? () => go("plan") : undefined,
    onMouseEnter: () => enrolled && setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      position: "relative",
      overflow: "hidden",
      cursor: enrolled ? "pointer" : "default",
      borderRadius: "var(--radius-card)",
      padding: "var(--card-pad)",
      background: hover ? "var(--surface-canvas-card-strong)" : "var(--surface-canvas-card)",
      border: "1px solid var(--border-canvas)",
      transform: hover ? "translateY(var(--hover-lift))" : "none",
      transition: "background-color var(--dur-base) var(--ease-standard),transform var(--dur-base) var(--ease-standard)",
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-3)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      insetInline: 0,
      top: 0,
      height: 4,
      background: c.color
    }
  }), /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-chevron-mark.png",
    alt: "",
    style: {
      position: "absolute",
      insetInlineStart: -18,
      bottom: -14,
      width: 120,
      opacity: .1,
      pointerEvents: "none"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-3)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 46,
      height: 46,
      borderRadius: "var(--radius-md)",
      background: c.color,
      color: "var(--tawr-navy-800)",
      display: "grid",
      placeItems: "center",
      flex: "0 0 auto"
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": c.icon
  })), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      color: "var(--text-on-canvas)",
      font: "var(--type-card-title)",
      flex: 1
    }
  }, c.name), enrolled ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-caption)",
      fontWeight: "var(--fw-bold)",
      color: "var(--tawr-navy-800)",
      background: "var(--tawr-teal-500)",
      borderRadius: "var(--radius-pill)",
      padding: "3px 10px",
      whiteSpace: "nowrap"
    }
  }, "\u0643\u0644\u064A\u062A\u064A") : c.optional && /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-caption)",
      fontWeight: "var(--fw-bold)",
      color: "var(--tawr-yellow-500)",
      border: "1px solid var(--tawr-yellow-500)",
      borderRadius: "var(--radius-pill)",
      padding: "3px 10px",
      whiteSpace: "nowrap"
    }
  }, "\u0627\u062E\u062A\u064A\u0627\u0631\u064A\u0629")), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--type-body)",
      color: "var(--text-on-canvas-muted)",
      margin: 0
    }
  }, c.desc), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "auto",
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-2)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      font: "var(--type-caption)",
      color: "var(--text-on-canvas-muted)"
    }
  }, /*#__PURE__*/React.createElement("span", null, "\u0627\u0644\u0645\u0633\u062A\u0648\u064A\u0627\u062A \u0627\u0644\u0645\u062C\u062A\u0627\u0632\u0629"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)"
    }
  }, c.passed, "/4")), /*#__PURE__*/React.createElement(ProgressBar, {
    value: c.passed,
    max: 4,
    color: c.color,
    height: 8
  })));
}
function HomeScreen({
  go
}) {
  const {
    colleges,
    levels
  } = window.TAWR;
  const enrolledId = "tech"; /* الكلية التي يدرسها الطالب */
  return /*#__PURE__*/React.createElement(CanvasPage, null, /*#__PURE__*/React.createElement(Hero, {
    go: go
  }), /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "0 var(--container-pad)",
      display: "grid",
      gridTemplateColumns: "repeat(4,1fr)",
      gap: "var(--gutter)"
    }
  }, /*#__PURE__*/React.createElement(StatTile, {
    tone: "brand",
    background: "#4EB9B6",
    value: "\u0665",
    label: "\u0643\u0644\u064A\u0627\u062A",
    sub: "\u064A\u062E\u062A\u0627\u0631 \u0627\u0644\u0637\u0627\u0644\u0628 \u0643\u0644\u064A\u0629 \u0648\u0627\u062D\u062F\u0629 \u0625\u0644\u0632\u0627\u0645\u064A\u064B\u0627"
  }), /*#__PURE__*/React.createElement(StatTile, {
    tone: "accent",
    background: "#FACB62",
    valueColor: "#26404D",
    value: "\u0664",
    label: "\u0645\u0633\u062A\u0648\u064A\u0627\u062A",
    sub: "\u0645\u0646 \u0627\u0644\u062F\u0628\u0644\u0648\u0645 \u0625\u0644\u0649 \u0627\u0644\u062F\u0643\u062A\u0648\u0631\u0627\u0647"
  }), /*#__PURE__*/React.createElement(StatTile, {
    tone: "ink",
    background: "#EE7C7D",
    subColor: "#FFFFFF",
    value: "\u0661",
    label: "\u0643\u0644\u064A\u0629 \u0625\u0644\u0632\u0627\u0645\u064A\u0629",
    sub: "\u064A\u062E\u062A\u0627\u0631\u0647\u0627 \u0627\u0644\u0637\u0627\u0644\u0628 \u0628\u0646\u0641\u0633\u0647"
  }), /*#__PURE__*/React.createElement(StatTile, {
    tone: "ink",
    background: "#2F4D5B",
    subColor: "#FFFFFF",
    value: "\u0661",
    label: "\u0643\u0644\u064A\u0629 \u0627\u062E\u062A\u064A\u0627\u0631\u064A\u0629",
    sub: "\u0627\u0644\u0645\u0647\u0627\u0631\u0627\u062A \u0648\u0627\u0644\u0642\u064A\u0627\u062F\u0629"
  })), /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "var(--space-20) var(--container-pad)"
    }
  }, /*#__PURE__*/React.createElement(SectionHead, {
    title: "\u0627\u0644\u0643\u0644\u064A\u0627\u062A \u0627\u0644\u062E\u0645\u0633",
    sub: "\u0643\u0644\u064A\u062A\u0643 \u0645\u0641\u062A\u0648\u062D\u0629 \u0644\u0644\u062F\u062E\u0648\u0644 \u0625\u0644\u0649 \u062E\u0637\u062A\u0647\u0627\u060C \u0648\u0628\u0642\u064A\u0629 \u0627\u0644\u0643\u0644\u064A\u0627\u062A \u0644\u0644\u0639\u0631\u0636 \u0641\u0642\u0637."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3,1fr)",
      gap: "var(--gutter)"
    }
  }, colleges.map(c => /*#__PURE__*/React.createElement(CollegeTile, {
    key: c.id,
    c: c,
    go: go,
    enrolled: c.id === enrolledId
  })))), /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "0 var(--container-pad) var(--space-20)"
    }
  }, /*#__PURE__*/React.createElement(SectionHead, {
    title: "\u0627\u0644\u0645\u0633\u062A\u0648\u064A\u0627\u062A \u0627\u0644\u0623\u0631\u0628\u0639\u0629",
    sub: "\u0623\u0633\u0645\u0627\u0621 \u0627\u0644\u062F\u0631\u062C\u0627\u062A \u0627\u0644\u062C\u0627\u0645\u0639\u064A\u0629 \u062A\u064F\u0633\u062A\u0639\u0645\u0644 \u0643\u0645\u0627 \u0647\u064A: \u0643\u0644 \u0645\u0633\u062A\u0648\u0649 \u064A\u064F\u062C\u062A\u0627\u0632 \u0628\u0627\u062E\u062A\u0628\u0627\u0631 \u0648\u0625\u0634\u0631\u0627\u0641 \u0645\u0639\u0644\u0645."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(4,1fr)",
      gap: "var(--gutter)"
    }
  }, levels.map((l, i) => /*#__PURE__*/React.createElement(DarkCard, {
    key: l.key,
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-3)"
    }
  }, /*#__PURE__*/React.createElement(LevelBadge, {
    level: l.key,
    showNumber: true,
    color: l.key === "diploma" ? "#99ACB4" : l.key === "phd" ? "#EE7C7D" : undefined,
    textColor: l.key === "diploma" ? "#E4EBEE" : undefined,
    numberColor: l.key === "diploma" ? "#FFFFFF" : undefined
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--type-body)",
      color: "var(--text-on-canvas-muted)",
      margin: 0
    }
  }, ["يُفتح للجميع عند بداية الكلية.", "يتطلب اجتياز الدبلوم في الكلية نفسها.", "مسألة متخصصة داخل الكلية.", "مشروع تخرّج بإشراف معلم."][i]), /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-chevron-mark.png",
    alt: "",
    style: {
      position: "absolute",
      insetInlineStart: -18,
      bottom: -14,
      width: 120,
      opacity: .1,
      pointerEvents: "none"
    }
  }))))));
}
Object.assign(window, {
  HomeScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Home.screen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Plan.screen.jsx
try { (() => {
const {
  Badge,
  ProgressBar,
  LevelBadge,
  Button,
  Alert
} = window.TawrUniversityDesignSystem_40b441;
function PlanScreen({
  go
}) {
  const {
    stages,
    colleges,
    levels
  } = window.TAWR;
  const tone = {
    passed: "success",
    current: "warning",
    open: "info"
  };
  const label = {
    passed: "مجتاز",
    current: "الحالي",
    open: "لاحقًا"
  };
  return /*#__PURE__*/React.createElement(CanvasPage, null, /*#__PURE__*/React.createElement(CanvasBackdrop, {
    opacity: .55,
    width: 330
  }), /*#__PURE__*/React.createElement("main", {
    style: {
      position: "relative",
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "var(--space-16) var(--container-pad) var(--space-20)"
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      color: "var(--text-on-canvas)",
      marginBottom: "var(--space-2)"
    }
  }, "\u0627\u0644\u062E\u0637\u0629 \u0627\u0644\u062F\u0631\u0627\u0633\u064A\u0629"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--type-body)",
      color: "var(--text-on-canvas-muted)",
      maxWidth: "60ch",
      marginBottom: "var(--space-8)"
    }
  }, "\u064A\u062E\u062A\u0627\u0631 \u0627\u0644\u0637\u0627\u0644\u0628 \u0643\u0644\u064A\u0629 \u0648\u0627\u062D\u062F\u0629 \u0625\u0644\u0632\u0627\u0645\u064A\u0629 \u064A\u0635\u0639\u062F \u0641\u064A \u0645\u0633\u062A\u0648\u064A\u0627\u062A\u0647\u0627 \u0627\u0644\u0623\u0631\u0628\u0639\u0629\u060C \u0648\u0644\u0647 \u0623\u0646 \u064A\u0636\u064A\u0641 \u0643\u0644\u064A\u0629 \u0627\u0644\u0645\u0647\u0627\u0631\u0627\u062A \u0648\u0627\u0644\u0642\u064A\u0627\u062F\u0629 \u0627\u062E\u062A\u064A\u0627\u0631\u064A\u0629."), /*#__PURE__*/React.createElement(Alert, {
    tone: "info",
    title: "\u0643\u0644\u064A\u0629 \u0648\u0627\u062D\u062F\u0629 \u0625\u0644\u0632\u0627\u0645\u064A\u0629",
    icon: /*#__PURE__*/React.createElement("i", {
      "data-lucide": "info"
    })
  }, "\u064A\u062E\u062A\u0627\u0631 \u0627\u0644\u0637\u0627\u0644\u0628 \u0643\u0644\u064A\u0629 \u0648\u0627\u062D\u062F\u0629 \u0641\u0642\u0637 \u0643\u0625\u0644\u0632\u0627\u0645\u064A\u0629 \u0648\u064A\u0635\u0639\u062F \u0641\u064A \u0645\u0633\u062A\u0648\u064A\u0627\u062A\u0647\u0627\u060C \u0648\u0643\u0644\u064A\u0629 \u0627\u0644\u0645\u0647\u0627\u0631\u0627\u062A \u0648\u0627\u0644\u0642\u064A\u0627\u062F\u0629 \u0627\u062E\u062A\u064A\u0627\u0631\u064A\u0629."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-4)",
      marginTop: "var(--space-8)"
    }
  }, stages.map((s, i) => /*#__PURE__*/React.createElement(DarkCard, {
    key: s.n,
    accent: s.state === "current" ? "var(--tawr-yellow-500)" : undefined,
    strong: s.state === "current",
    style: {
      display: "grid",
      gridTemplateColumns: "88px 1fr auto",
      gap: "var(--space-5)",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      placeItems: "center",
      width: 72,
      height: 72,
      borderRadius: "var(--radius-md)",
      background: s.state === "open" ? "rgba(0,0,0,.18)" : "var(--tawr-teal-800)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--fw-extrabold) 30px/1 var(--font-display)",
      color: s.state === "open" ? "var(--text-on-canvas-muted)" : "#fff"
    }
  }, ["١", "٢", "٣", "٤"][i])), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      color: "var(--text-on-canvas)",
      marginBottom: 4
    }
  }, s.n), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--type-body)",
      color: "var(--text-on-canvas-muted)",
      margin: 0
    }
  }, s.focus)), /*#__PURE__*/React.createElement(Badge, {
    tone: tone[s.state],
    dot: s.state === "current"
  }, label[s.state])))), /*#__PURE__*/React.createElement(DarkCard, {
    style: {
      marginTop: "var(--space-10)"
    },
    padding: "var(--space-8)"
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      color: "var(--text-on-canvas)",
      marginBottom: "var(--space-5)"
    }
  }, "\u062A\u0642\u062F\u0651\u0645\u0643 \u0639\u0628\u0631 \u0627\u0644\u0643\u0644\u064A\u0627\u062A"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-4)"
    }
  }, colleges.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.id,
    style: {
      display: "grid",
      gridTemplateColumns: "200px 1fr 44px",
      alignItems: "center",
      gap: "var(--space-4)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-body-strong)",
      color: "var(--text-on-canvas)"
    }
  }, c.name), /*#__PURE__*/React.createElement(ProgressBar, {
    value: c.passed,
    max: 4,
    color: c.color,
    height: 10
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-caption)",
      fontFamily: "var(--font-mono)",
      color: "var(--text-on-canvas-muted)",
      textAlign: "left"
    }
  }, c.passed, "/4")))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-2)",
      marginTop: "var(--space-6)",
      flexWrap: "wrap"
    }
  }, levels.map(l => /*#__PURE__*/React.createElement(LevelBadge, {
    key: l.key,
    level: l.key,
    size: "sm"
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--space-8)"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    onClick: () => go("signup")
  }, "\u0633\u062C\u0651\u0644 \u0627\u0644\u0622\u0646"))));
}
Object.assign(window, {
  PlanScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Plan.screen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Signup.screen.jsx
try { (() => {
const {
  Button,
  Input,
  Select,
  Tabs,
  Logo
} = window.TawrUniversityDesignSystem_40b441;

/* شاشة تسجيل بعمودين — مبنية على هوية طور: خلفية الشيفرون، والتيل/الأصفر/المرجاني. */
function StepItem({
  number,
  text,
  active,
  color
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-3)",
      padding: "var(--space-3) var(--space-4)",
      borderRadius: "var(--radius-pill)",
      background: active ? "#fff" : "rgba(22,39,47,.72)",
      border: active ? "var(--stroke) solid #fff" : "1px solid var(--border-canvas)",
      color: active ? "var(--tawr-navy-800)" : "var(--text-on-canvas)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 26,
      height: 26,
      borderRadius: "50%",
      flex: "0 0 auto",
      display: "grid",
      placeItems: "center",
      font: "var(--fw-bold) 12px/1 var(--font-mono)",
      background: active ? color || "var(--tawr-teal-600)" : "rgba(255,255,255,.1)",
      color: active ? "#fff" : "var(--text-on-canvas-muted)"
    }
  }, number), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--type-body-strong)"
    }
  }, text));
}
function SignupScreen({
  go
}) {
  const [mode, setMode] = React.useState("login");
  const [reveal, setReveal] = React.useState(false);
  const [done, setDone] = React.useState(false);
  const isLogin = mode === "login";
  const dark = {
    "--text-strong": "var(--text-on-canvas)",
    "--surface-card": "rgba(255,255,255,.06)",
    "--surface-sunken": "rgba(0,0,0,.28)",
    "--border-default": "var(--border-canvas)",
    "--text-muted": "var(--text-on-canvas-muted)"
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      height: "calc(100vh - 84px)",
      overflow: "hidden",
      background: "var(--surface-canvas)",
      padding: "var(--space-4)",
      gap: "var(--space-4)"
    }
  }, /*#__PURE__*/React.createElement("aside", {
    style: {
      position: "relative",
      width: "52%",
      flex: "0 0 52%",
      borderRadius: "var(--radius-2xl)",
      overflow: "hidden",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "flex-start",
      padding: "var(--space-10) var(--space-12)",
      height: "100%",
      overflowY: "auto",
      boxShadow: "var(--shadow-lg)",
      background: "var(--tawr-navy-800)"
    }
  }, /*#__PURE__*/React.createElement(CanvasBackdrop, {
    opacity: .75,
    width: 330
  }), /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      inset: 0,
      left: -26,
      top: 8,
      background: "linear-gradient(270deg,#0F0C08EB,rgba(22,39,47,.74) 55%,rgba(22,39,47,.32) 100%)"
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    src: "../../assets/logo-wordmark-transparent.png",
    height: 88,
    style: {
      objectFit: "contain",
      position: "absolute",
      left: 444,
      top: 6
    }
  })), /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-chevron-mark.png",
    alt: "",
    "aria-hidden": "true",
    style: {
      position: "absolute",
      insetInlineStart: "6%",
      bottom: "6%",
      width: "34%",
      opacity: .12,
      pointerEvents: "none"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      zIndex: 1,
      width: "100%",
      maxWidth: 340,
      left: 189,
      top: 207,
      marginBlock: "auto",
      flex: "0 0 auto",
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-6)"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: "var(--fw-extrabold) 38px/1.15 var(--font-display)",
      color: "var(--text-on-canvas)",
      whiteSpace: "nowrap"
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--type-body)",
      color: "var(--text-on-canvas-muted)",
      margin: "var(--space-3) 0 0"
    }
  }, "\u0627\u062F\u062E\u0644 \u0628\u062D\u0633\u0627\u0628\u0643\u060C \u0623\u0648 \u0623\u0646\u0634\u0626 \u062D\u0633\u0627\u0628\u064B\u0627 \u062C\u062F\u064A\u062F\u064B\u0627 \u0641\u064A \u062B\u0644\u0627\u062B \u062E\u0637\u0648\u0627\u062A.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-3)"
    }
  }, /*#__PURE__*/React.createElement(StepItem, {
    number: "\u0661",
    text: "\u0633\u062C\u0651\u0644 \u0628\u064A\u0627\u0646\u0627\u062A\u0643",
    active: true,
    color: "var(--tawr-teal-600)"
  }), /*#__PURE__*/React.createElement(StepItem, {
    number: "\u0662",
    text: "\u0627\u062E\u062A\u0631 \u0643\u0644\u064A\u062A\u0643 \u0627\u0644\u0625\u0644\u0632\u0627\u0645\u064A\u0629"
  }), /*#__PURE__*/React.createElement(StepItem, {
    number: "\u0663",
    text: "\u0623\u0643\u0645\u0644 \u0645\u0644\u0641\u0643 \u0627\u0644\u0634\u062E\u0635\u064A"
  })))), /*#__PURE__*/React.createElement("section", {
    style: {
      flex: 1,
      minWidth: 0,
      height: "100%",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      padding: "var(--space-12) var(--space-10)",
      overflowY: "auto"
    }
  }, done ? /*#__PURE__*/React.createElement("div", {
    style: {
      width: "100%",
      maxWidth: 560,
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-4)",
      alignItems: "flex-start"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-chevron-mark.png",
    alt: "",
    style: {
      height: 44,
      width: "auto"
    }
  }), /*#__PURE__*/React.createElement("h1", {
    style: {
      font: "var(--fw-extrabold) 30px/1.2 var(--font-display)",
      color: "var(--text-on-canvas)"
    }
  }, isLogin ? "مرحبًا بك" : "وصل طلبك"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--type-body)",
      color: "var(--text-on-canvas-muted)",
      maxWidth: "44ch"
    }
  }, isLogin ? "تم الدخول إلى حسابك." : "سيتواصل معك أحد المعلمين المشرفين لتأكيد المقعد قبل البداية."), /*#__PURE__*/React.createElement(Button, {
    variant: "accent",
    onClick: () => setDone(false)
  }, "\u0631\u062C\u0648\u0639")) : /*#__PURE__*/React.createElement("div", {
    style: {
      ...dark,
      width: "100%",
      maxWidth: 560,
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-6)"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      font: "var(--fw-extrabold) 30px/1.2 var(--font-display)",
      color: "var(--text-on-canvas)"
    }
  }, isLogin ? "تسجيل الدخول" : "حساب جديد"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--type-body)",
      color: "#FACB62",
      margin: "var(--space-2) 0 0"
    }
  }, isLogin ? "أدخل اسمك وكلمة المرور للمتابعة." : "أدخل بياناتك لإنشاء حسابك.")), /*#__PURE__*/React.createElement("div", {
    style: {
      "--tawr-teal-600": "#4EB9B6"
    }
  }, /*#__PURE__*/React.createElement(Tabs, {
    value: mode,
    onChange: setMode,
    items: [{
      value: "login",
      label: "تسجيل الدخول"
    }, {
      value: "signup",
      label: "حساب جديد"
    }]
  })), isLogin ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      "--text-strong": "#EE7C7D"
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "\u0627\u0644\u0627\u0633\u0645",
    placeholder: "\u0627\u0643\u062A\u0628 \u0627\u0633\u0645\u0643",
    icon: /*#__PURE__*/React.createElement("i", {
      "data-lucide": "user"
    })
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      "--text-strong": "#EE7C7D"
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631",
    type: reveal ? "text" : "password",
    placeholder: "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022"
  }), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: () => setReveal(r => !r),
    "aria-label": "\u0625\u0638\u0647\u0627\u0631 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631",
    style: {
      position: "absolute",
      left: 12,
      top: 38,
      background: "transparent",
      border: "none",
      cursor: "pointer",
      color: "var(--text-on-canvas-muted)",
      display: "grid",
      placeItems: "center",
      padding: 6
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": reveal ? "eye-off" : "eye"
  }))), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    fullWidth: true,
    onClick: () => setDone(true),
    style: {
      marginTop: "var(--space-2)",
      backgroundColor: "#4EB9B6"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "#26404D"
    }
  }, "\u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644"))) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: "var(--space-4)"
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "\u0627\u0644\u0627\u0633\u0645 \u0627\u0644\u0623\u0648\u0644",
    placeholder: "\u0645\u062D\u0645\u062F"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "\u0627\u0633\u0645 \u0627\u0644\u0639\u0627\u0626\u0644\u0629",
    placeholder: "\u0627\u0644\u0639\u062A\u064A\u0628\u064A"
  })), /*#__PURE__*/React.createElement(Input, {
    label: "\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A",
    type: "email",
    placeholder: "name@example.com",
    icon: /*#__PURE__*/React.createElement("i", {
      "data-lucide": "mail"
    })
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: "var(--space-4)"
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "\u0631\u0642\u0645 \u0627\u0644\u062C\u0648\u0627\u0644",
    placeholder: "05xxxxxxxx",
    icon: /*#__PURE__*/React.createElement("i", {
      "data-lucide": "phone"
    })
  }), /*#__PURE__*/React.createElement(Select, {
    label: "\u0627\u0644\u0645\u0631\u062D\u0644\u0629",
    placeholder: "\u0627\u062E\u062A\u0631 \u0627\u0644\u0645\u0631\u062D\u0644\u0629",
    options: [{
      value: "1",
      label: "أول ثانوي"
    }, {
      value: "2",
      label: "ثاني ثانوي"
    }, {
      value: "3",
      label: "ثالث ثانوي"
    }]
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631",
    type: reveal ? "text" : "password",
    placeholder: "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022",
    hint: "\u062B\u0645\u0627\u0646\u064A\u0629 \u0631\u0645\u0648\u0632 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644."
  }), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: () => setReveal(r => !r),
    "aria-label": "\u0625\u0638\u0647\u0627\u0631 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631",
    style: {
      position: "absolute",
      left: 12,
      top: 38,
      background: "transparent",
      border: "none",
      cursor: "pointer",
      color: "var(--text-on-canvas-muted)",
      display: "grid",
      placeItems: "center",
      padding: 6
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": reveal ? "eye-off" : "eye"
  }))), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    fullWidth: true,
    onClick: () => setDone(true),
    style: {
      marginTop: "var(--space-2)"
    }
  }, "\u0623\u0646\u0634\u0626 \u0627\u0644\u062D\u0633\u0627\u0628")), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--type-body)",
      fontSize: "var(--fs-body-sm)",
      color: "var(--text-on-canvas-muted)",
      textAlign: "center",
      margin: 0
    }
  }, isLogin ? "ليس لديك حساب؟ " : "لديك حساب؟ ", /*#__PURE__*/React.createElement("a", {
    href: "#switch",
    onClick: e => {
      e.preventDefault();
      setMode(isLogin ? "signup" : "login");
    },
    style: {
      color: "#FACB62",
      borderBottom: "1px solid rgba(99,196,193,.4)"
    }
  }, isLogin ? "أنشئ حسابًا" : "ادخل الآن")))));
}
Object.assign(window, {
  SignupScreen,
  StepItem
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Signup.screen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/app.jsx
try { (() => {
function SiteApp() {
  const [route, setRoute] = React.useState("home");
  const go = r => {
    setRoute(r);
    window.scrollTo({
      top: 0
    });
  };
  React.useEffect(() => {
    window.lucide && window.lucide.createIcons();
  });
  const screens = {
    home: HomeScreen,
    plan: PlanScreen,
    attendance: AttendanceScreen,
    signup: SignupScreen
  };
  const Screen = screens[route] || HomeScreen;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: "100vh",
      display: "flex",
      flexDirection: "column"
    }
  }, /*#__PURE__*/React.createElement(SiteHeader, {
    route: route,
    go: go
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement(Screen, {
    go: go
  })), /*#__PURE__*/React.createElement(SiteFooter, null));
}
ReactDOM.createRoot(document.getElementById("root")).render(/*#__PURE__*/React.createElement(SiteApp, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/data.js
try { (() => {
window.TAWR = {
  colleges: [{
    id: "sharia",
    name: "كلية الشريعة",
    color: "var(--faculty-sharia)",
    icon: "book-marked",
    passed: 1,
    desc: "أصول الفقه والعبادات وأحكام المعاملات."
  }, {
    id: "seerah",
    name: "كلية السيرة والتاريخ",
    color: "var(--faculty-seerah)",
    icon: "landmark",
    passed: 2,
    desc: "السيرة النبوية وتاريخ الأمة ورجالها."
  }, {
    id: "quran",
    name: "كلية القرآن وعلومه",
    color: "var(--faculty-quran)",
    icon: "book-open",
    passed: 1,
    desc: "الحفظ والتجويد والتفسير وعلوم القرآن."
  }, {
    id: "tech",
    name: "كلية التقنية",
    color: "var(--faculty-tech)",
    icon: "cpu",
    passed: 2,
    desc: "البرمجة والتصميم والأمن الرقمي."
  }, {
    id: "skills",
    name: "كلية المهارات والقيادة",
    color: "var(--faculty-skills)",
    icon: "users",
    passed: 3,
    desc: "القيادة والعمل الجماعي وإدارة المبادرات.",
    optional: true
  }],
  levels: [{
    key: "diploma",
    label: "دبلوم"
  }, {
    key: "bachelor",
    label: "بكالوريوس"
  }, {
    key: "master",
    label: "ماجستير"
  }, {
    key: "phd",
    label: "دكتوراه"
  }],
  stages: [{
    n: "الدبلوم",
    focus: "مدخل الكلية ومصطلحاتها الأساسية",
    state: "passed"
  }, {
    n: "البكالوريوس",
    focus: "التوسّع في الأصول وورشة عملية",
    state: "passed"
  }, {
    n: "الماجستير",
    focus: "مسألة متخصصة وبحث قصير",
    state: "current"
  }, {
    n: "الدكتوراه",
    focus: "مشروع التخرّج بإشراف معلم",
    state: "open"
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/data.js", error: String((e && e.message) || e) }); }

__ds_ns.CollegeCard = __ds_scope.CollegeCard;

__ds_ns.LevelBadge = __ds_scope.LevelBadge;

__ds_ns.Logo = __ds_scope.Logo;

__ds_ns.PatternBand = __ds_scope.PatternBand;

__ds_ns.StatTile = __ds_scope.StatTile;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Alert = __ds_scope.Alert;

__ds_ns.ProgressBar = __ds_scope.ProgressBar;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
