# جامعة طور — Tawr University Design System

**Tawr University (جامعة طور)** is not a degree-granting university. It is a **six-semester youth development program for high-school students, staged as a university**: inside it sit **six "colleges" (كليات)**, each with **four levels (مستويات)** named after academic degrees — **دبلوم / بكالوريوس / ماجستير / دكتوراة**. Every student must clear **at least level 1 of every college**, then may specialize upward.

**The six colleges**
1. كلية الشريعة — Sharia
2. كلية السيرة والتاريخ — Seerah & History
3. كلية القرآن وعلومه — Qur'an & its Sciences
4. كلية التقنية — Technology
5. كلية اللغة العربية — Arabic Language
6. كلية المهارات والقيادة — Skills & Leadership

Students are high-schoolers; delivery is supervised by teachers/mentors (معلمون). Named committees run the program's output — the supplied poster is signed `#اللجنة_الإعلامية` (the Media Committee), so **committee-signed collateral is a real, recurring artifact type**.

The name **طور** carries the program's whole idea: *to develop / to evolve*, and *a stage or phase* (طَور). The chevron mark reads as ascent — a step upward, a level cleared.

---

## Sources given to me

Uploaded files (in `uploads/`, originals preserved):

| File | What it is |
|---|---|
| `الشعار.pdf.pdf ٥.pdf` | Master logo sheet — the wordmark on navy, teal, yellow and coral backgrounds. Primary source of the palette. |
| `الشعار.pdf.png ٢.png` | Wordmark, teal on navy, 3000px |
| `الشعار.pdf.png. طور خلفية .png` | Wordmark, full colour on white, 3000px |
| `Untitled design - 1.PNG` | 16:9 banner — navy chevron field on yellow, wordmark top-right. Source of the pattern asset. |
| `PHOTO-2026-02-05-22-55-03.jpg` | Social poster, "من صنع يدي", `#اللجنة_الإعلامية` — shows the dark-mode poster idiom, arc lines, glow, outlined chevrons |
| `نسخة من عرض رياضي.png ٧٦.png` | **The master brand composition** — navy `#38515E` ground, scattered coral/yellow chevrons at full saturation on the left, teal wordmark bottom-right. This is the canonical layout the whole system is built on. |
| `تيشرت2.pdf` | Team t-shirt mock — teal body, navy raglan shoulders, chevron confetti hem in yellow/coral/teal |

**No codebase, Figma file, or product UI was provided.** There is therefore no source-of-truth component inventory, and no existing screens to recreate. Consequences, stated plainly:

- The **component set is a from-scratch standard set** (Button, Input, Card, …), authored to the brand's visual language.
- The **UI kits are brand-derived constructions, not recreations.** They compose only motifs that exist in the supplied assets (palette, chevron field, monoline geometry, RTL Arabic). If you have real screens or a Figma file, send them — the kits should be re-cut against them.
- **No font files were supplied.** See *Type* below for the substitutions I made and what I need from you.

---

## CONTENT FUNDAMENTALS

**Language.** Arabic first, always. Every surface is `dir="rtl"`. Latin appears only for numerals in data contexts and for the occasional loanword; do not write English marketing copy for this brand. Numerals: Arabic-Indic (`١٢٣`) in editorial/poster contexts (the brief itself writes ٦ فصول, ٤ مستويات); Western (`123`) inside product UI where alignment and scanning matter.

**Voice.** Warm institutional. It speaks as the program — *نحن* implied rather than stated — and addresses the student directly as **أنت** (`ابدأ رحلتك`, `اجتز المستوى الأول`). Imperative verbs carry calls to action; they are short and unhedged.

**Register.** Classical-leaning but plain — Fusha without ornament. No slang, no youth-pandering, no exclamation stacking. Program vocabulary is borrowed wholesale from academia and used seriously: كلية، مستوى، فصل دراسي، دبلوم، بكالوريوس، ماجستير، دكتوراة، اجتياز، إشراف. That borrowed vocabulary IS the brand's central conceit — never soften it to "course" or "track".

**Length.** Poster and hero lines are very short — three to five words (`من صنع يدي`). Explanatory copy is one or two sentences, never a paragraph wall. Card bodies cap at ~110 characters of Arabic.

**Casing & punctuation.** Arabic has no case; emphasis is carried by weight and colour, never by ALL-CAPS transliteration. Titles take no terminal full stop. Body sentences do. Hashtags are underscore-joined and used as a *signature*, set apart at the foot of a poster: `#اللجنة_الإعلامية`, `#جامعة_طور`.

**Emoji.** Used in the program's own internal/WhatsApp-style announcements (the brief uses 👇 and ⬇️ as list pointers) but **never in designed collateral or product UI**. Do not put emoji in a card, a button, or a poster. If a pointer is needed, use the chevron mark.

**Examples in the brand's voice**
- Hero: `ست كليات. أربعة مستويات. طورٌ واحد.`
- Sub: `خطة تمتد ستة فصول دراسية، يجتاز فيها الطالب المستوى الأول من كل كلية كحد أدنى.`
- CTA: `ابدأ التسجيل` · `تابع مستواك` · `اطّلع على الخطة`
- Empty state: `لم تبدأ أي مستوى بعد.`
- Poster signature: `#اللجنة_الإعلامية`

---

## VISUAL FOUNDATIONS

### Colour
Four hues, sampled from the supplied logo PDF, and nothing else:

| Role | Hex | Use |
|---|---|---|
| Teal | `#4EB9B6` | The brand. Wordmark, primary buttons, progress, links. |
| Navy | `#38515E` (`--tawr-navy-canvas`) | **The default ground of every branded surface.** `#2F4D5B` (`--tawr-navy-600`) remains the ink for body text on light surfaces. |
| Yellow | `#FACB62` | Warm accent + full-bleed alternate ground. Highlights, level "ماجستير", banner fields. |
| Coral | `#EE7C7D` | Second accent. The larger chevron of the mark, "دكتوراة", warnings. |

Rules seen in the sources: **any of the four can be the full-bleed ground**, and the wordmark simply flips between teal and navy for contrast (teal wordmark on navy; navy wordmark on teal, yellow, coral, white). Never place teal on coral or coral on teal. Two grounds maximum per artifact. Neutrals are navy-tinted (`--tawr-navy-100…300`), never pure grey. Page background is `#F7FAFA`, a barely-teal paper.

### Type
Display: **Tajawal** (800/900). Text: **Cairo** (400–700). Both are Google-hosted **substitutions** — the wordmark is custom lettering and no font files came with the brief. Tajawal was chosen because it shares the wordmark's monoline geometry and open, circular counters; Cairo carries small sizes and Latin numerals better. Scale is 11 → 64px with a strong jump between `--fs-title-1` (30) and `--fs-display-3` (38) — headlines are meant to be *much* larger than body, as on the poster. Arabic line-height runs generous (`--lh-normal:1.6`) because of descenders and diacritics; never tighten body Arabic below 1.5.

### Backgrounds
**The default is the master composition:** navy `#38515E` edge to edge, with the scattered chevron field (`assets/pattern-chevrons-scatter.png`) anchored to the **start edge of the composition** (visually left), full saturation, fading out toward the content with a linear mask. Content sits in the clear navy on the opposite side. The wordmark closes the composition on the far side.

Rules for the field: never scale it so a single chevron exceeds ~180px; never tile it visibly across a whole page — scope it to a hero, a footer, or the head of a page and let the rest of the surface stay clean navy. It repeats vertically at a fixed column width (330–470px in the kits).

Two secondary idioms exist in the sources and remain valid for collateral only:
- **Bottom-anchored chevron hem** on a yellow ground (`assets/pattern-chevrons-navy-on-yellow.png`) — banners, t-shirt hems.
- **Dark editorial poster** — navy ground, thin concentric arc lines in yellow and coral, soft glow, silhouetted subject, headline at the foot.

Full-bleed navy is the norm everywhere. Cards float on it as translucent white panels (see *Cards*).

### Imagery
Cool and dark: navy-shifted, low-key, high-contrast silhouettes rather than lit photography. Subjects read as shapes. Where a photo meets text, a `--protect-gradient` (navy, bottom-up) carries the type — capsules are not used over imagery. No grain, no duotone overlays other than the navy shift.

### Shape & radii
The wordmark is monoline with fully rounded terminals, so **radii are generous and never sharp**: cards 18px, inputs 12px, buttons and chips fully pill (`--radius-pill`). The chevron itself is the only angular form in the system, and its own corners are rounded ~6px. Nothing in the system has a 0px corner except full-bleed sections.

### Cards
**On the navy canvas (the default):** a translucent white panel — `rgba(255,255,255,.07)` fill, 1px `rgba(255,255,255,.16)` border, `--radius-lg`, a light backdrop blur, no drop shadow. Hover raises the fill to `.12` and lifts 2px. Tokens: `--surface-canvas-card`, `--surface-canvas-card-strong`, `--border-canvas`.

**On paper (documents, print, light embeds):** white surface, `--radius-lg`, no border — separation comes from `--shadow-sm`.

Either way a card may carry a **top-edge colour bar** (4px, faculty colour) or a chevron glyph watermark at ~10% opacity. Never a coloured left-border-only card.

### Borders & strokes
1px `--border-subtle` for dividers, 2px for selected/active states, 3px for the outlined-chevron decorative idiom. Focus is a 2px teal outline at 2px offset — never removed.

### Shadows
Navy-tinted and soft (`rgba(22,39,47,…)`, 6–12% alpha, generous blur, no spread). Coloured shadows (`--shadow-brand`, `--shadow-accent`) are for raised primary buttons and floating brand elements only. Inner shadow appears once: inputs, `--shadow-inset`, very light. No hard 1px offset shadows, no neumorphism.

### Transparency & blur
Sparingly. Glass (`--blur-glass`, navy at 62%) is used for a sticky header over a scrolled hero and for modal scrims — nowhere else. Decorative chevrons sit at 8–20% opacity as watermarks. Text is never set on a blur without a solid or gradient carrier.

### Motion
Quiet and upward. Standard easing `cubic-bezier(.2,.8,.2,1)`, 160–220ms for state changes; entrances use `--ease-rise` over 360ms and move **up** 8–16px with a fade — the ascent metaphor. No bounce, no spring overshoot, no parallax. Progress fills animate left-to-right in RTL terms (i.e. right-to-left visually) over `--dur-slow`.

### Interaction states
- **Hover (solid):** darken one ramp step (`teal-600 → teal-700`) and lift `--hover-lift` (-2px) with the next shadow up.
- **Hover (ghost/outline):** fill with the soft tint (`--surface-brand-soft`), no lift.
- **Hover (card):** shadow `sm → md`, lift 2px, no colour change.
- **Press:** `scale(var(--press-scale))` = 0.97, shadow drops to `xs`, colour darkens a further step. Never a colour-only press.
- **Disabled:** 40% opacity, `--surface-sunken` fill, no shadow, `cursor:not-allowed`.
- **Selected:** 2px teal border + `--surface-brand-soft` fill + weight bump to 700.

### Layout
`--container-max:1200px`, 24px gutters, 96px between sections. RTL grid: logo top-**right**, nav flows right-to-left, progress bars fill right-to-left. Sticky elements: the site header (glass on scroll) and, in the app, the bottom tab bar. Content columns cap at ~70 characters of Arabic. The 6-college grid is 3×2 on desktop, 2×3 on tablet, 1×6 on mobile — that 6-up grid is the brand's signature layout unit.

---

## ICONOGRAPHY

**What the brand actually owns:** one glyph — the **chevron** (`assets/logo-chevron-mark.png`). It appears as the two-tone mark above the wordmark (yellow small + coral large), as the scattered field in the master composition, as the confetti hem in the banner and t-shirt, and as thin outlined clusters on the poster. In the field it appears at several scales and in two weights — small solid chevrons and large "stacked" compound chevrons formed by overlapping two. It is the brand's bullet, its progress step, its watermark, and its list pointer. Use it in place of a generic arrow or check wherever it fits.

**What the brand does not own:** a UI icon set. None was supplied — no icon font, no SVG sprite, no PNG icons anywhere in the uploads.

**Substitution (FLAGGED):** UI icons use **Lucide** from CDN (`https://unpkg.com/lucide@latest`), 24px, `stroke-width:2`, round caps and joins — chosen because its monoline, round-terminal drawing is the closest available match to the wordmark's construction. This is my choice, not the brand's; if the program has an icon set, send it and I will swap it in.

**Emoji as icons:** never in design. Unicode characters are not used as icons either. Numerals — level numbers ١–٤ — are used *as* graphic marks inside chevrons and circles, which is authentic to the brand.

---

## Intentional additions

Because no source defined a component inventory, everything under `components/` is authored, not copied. Two components are brand-specific rather than generic, and exist because the program's information architecture demands them:

- **`CollegeCard`** — the six-college grid is the brand's signature layout unit; it needs one card shape.
- **`LevelBadge`** — دبلوم/بكالوريوس/ماجستير/دكتوراة recur on nearly every surface and carry fixed colours.
- **`PatternBand` / `Logo`** — wrappers so the real assets are used instead of hand-drawn approximations.

---

## Index

**Root**
- `styles.css` — the only stylesheet consumers link; `@import`s everything in `tokens/`
- `readme.md` — this file · `SKILL.md` — Agent-Skills entry point · `thumbnail.html` — homepage tile

**`tokens/`** — `fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `radius.css`, `elevation.css`, `motion.css`, `base.css`

**`assets/`**
- `logo-wordmark-transparent.png` — **primary mark.** Teal wordmark + two-tone chevron, transparent background, for use on the navy canvas
- `logo-wordmark-on-navy.png` — the same mark pre-composited on `#38515E`
- `logo-chevron-mark.png` — the chevron mark alone, transparent
- `brand-bg-chevrons-navy.png` — **the master composition**, full frame
- `pattern-chevrons-scatter.png` — the scattered chevron field cut from it, for backdrops
- `logo-wordmark.png` / `logo-wordmark-on-dark.png` — earlier logo-sheet crops, kept for reference
- `pattern-chevrons-navy-on-yellow.png` — the bottom-anchored hem field (collateral)
- `pattern-banner-yellow.png` — full 16:9 banner as supplied
- `poster-media-committee.jpg` — dark editorial poster reference

**`components/`**
- `core/` — `Button`, `IconButton`, `Card`, `Badge`, `Tag`
- `forms/` — `Input`, `Select`, `Checkbox`, `Switch`
- `navigation/` — `Tabs`
- `feedback/` — `ProgressBar`, `Alert`
- `brand/` — `Logo`, `PatternBand`, `CollegeCard`, `LevelBadge`, `StatTile`

**`guidelines/`** — foundation specimen cards (colour, type, spacing, radii, shadows, motion, brand marks)

**`ui_kits/`**
- `website/` — public program site, RTL, built entirely on the navy chevron canvas (hero, six-college grid, plan, enrollment)
- `student_app/` — student portal, RTL mobile (dashboard, college, level, progress)
