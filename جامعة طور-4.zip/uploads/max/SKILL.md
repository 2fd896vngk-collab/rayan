---
name: tawr-design
description: Use this skill to generate well-branded interfaces and assets for جامعة طور (Tawr University), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for protoyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

Non-negotiables for this brand: Arabic RTL always; the navy `#38515E` canvas with the scattered chevron field is the default ground; the wordmark is an image asset and is never redrawn or retyped; no emoji in designed output.
