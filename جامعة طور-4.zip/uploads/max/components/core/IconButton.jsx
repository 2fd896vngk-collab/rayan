import React from "react";

const TONES = {
  brand:{bg:"var(--tawr-teal-600)",hover:"var(--tawr-teal-700)",fg:"#fff"},
  ink:{bg:"var(--tawr-navy-600)",hover:"var(--tawr-navy-700)",fg:"#fff"},
  soft:{bg:"var(--surface-brand-soft)",hover:"var(--tawr-teal-200)",fg:"var(--text-brand)"},
  quiet:{bg:"transparent",hover:"var(--surface-sunken)",fg:"var(--text-body)"},
  glass:{bg:"rgba(255,255,255,.14)",hover:"rgba(255,255,255,.24)",fg:"#fff"}
};
const S={sm:32,md:40,lg:48};

export function IconButton({icon,tone="quiet",size="md",label,disabled,onClick,style:styleOverride,...rest}){
  const [hover,setHover]=React.useState(false);
  const [press,setPress]=React.useState(false);
  const t=TONES[tone]||TONES.quiet, d=S[size]||S.md;
  return React.createElement("button",{type:"button","aria-label":label,disabled,onClick,
    onMouseEnter:()=>setHover(true),onMouseLeave:()=>{setHover(false);setPress(false)},
    onMouseDown:()=>setPress(true),onMouseUp:()=>setPress(false),
    style:{width:d,height:d,display:"inline-grid",placeItems:"center",borderRadius:"var(--radius-pill)",
      border:"none",cursor:disabled?"not-allowed":"pointer",opacity:disabled?.4:1,
      background:hover&&!disabled?t.hover:t.bg,color:t.fg,
      transform:press?"scale(var(--press-scale))":"none",transition:"var(--transition-control)",...styleOverride},
    ...rest}, icon);
}
