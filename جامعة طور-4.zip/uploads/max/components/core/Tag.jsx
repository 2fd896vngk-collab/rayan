import React from "react";

export function Tag({children,color="var(--tawr-teal-600)",selected,onClick,onRemove,...rest}){
  const [hover,setHover]=React.useState(false);
  const clickable=!!onClick;
  return React.createElement("span",{onClick,
    onMouseEnter:()=>setHover(true),onMouseLeave:()=>setHover(false),
    style:{display:"inline-flex",alignItems:"center",gap:"var(--space-2)",
      padding:"7px 14px",borderRadius:"var(--radius-chip)",font:"var(--type-label)",
      color:selected?"#fff":color,
      background:selected?color:hover&&clickable?"var(--surface-brand-soft)":"transparent",
      border:`var(--stroke) solid ${selected?color:"var(--border-default)"}`,
      cursor:clickable?"pointer":"default",transition:"var(--transition-control)"},...rest},
    children,
    onRemove?React.createElement("span",{onClick:(e)=>{e.stopPropagation();onRemove()},
      style:{cursor:"pointer",opacity:.65,fontSize:14,lineHeight:1}},"×"):null);
}
