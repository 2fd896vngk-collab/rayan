One-line: the default surface for every piece of content that is not full-bleed.

```jsx
<Card interactive accent="var(--faculty-tech)" watermark="assets/logo-chevron-mark.png">
  <h3>كلية التقنية</h3>
  <p>أربعة مستويات تبدأ من الدبلوم.</p>
</Card>
```

- Never give a card a coloured left border. The only colour affordance is the 4px `accent` bar on the top edge.
- `tone="ink"` for dark editorial blocks inside a light page; `tone="brand"` for a single highlighted card per view.
