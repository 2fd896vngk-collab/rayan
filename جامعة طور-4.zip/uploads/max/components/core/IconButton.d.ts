import * as React from "react";

/** Circular single-glyph control — toolbar actions, close buttons, media controls. */
export interface IconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  icon: React.ReactNode;
  /** brand = teal fill, ink = navy fill, soft = teal tint, quiet = transparent, glass = for use over imagery */
  tone?: "brand" | "ink" | "soft" | "quiet" | "glass";
  size?: "sm" | "md" | "lg";
  /** Accessible label — required, the button has no text */
  label: string;
  disabled?: boolean;
}
export declare function IconButton(props: IconButtonProps): JSX.Element;
