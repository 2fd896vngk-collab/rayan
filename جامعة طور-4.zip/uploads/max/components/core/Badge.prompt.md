One-line: status pill — "مجتاز", "قيد الدراسة", counts, level states.

```jsx
<Badge tone="success" dot>مجتاز</Badge>
```

Soft tint by default; `solid` only when the badge must read at a glance from a distance (e.g. on a dark hero).
