import * as React from "react";

/** Small pill for status and counts — reuses the four brand hues, never introduces a new one. */
export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  tone?: "brand" | "success" | "warning" | "danger" | "info" | "solid";
  /** Leading status dot */
  dot?: boolean;
  /** Inverts to a filled pill with white text */
  solid?: boolean;
  children?: React.ReactNode;
}
export declare function Badge(props: BadgeProps): JSX.Element;
