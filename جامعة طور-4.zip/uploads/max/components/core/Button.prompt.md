One-line: the brand's action control — pill, teal by default, used for every commit action in Arabic RTL layouts.

```jsx
<Button variant="primary" size="lg" iconStart={<i data-lucide="arrow-left" />}>ابدأ التسجيل</Button>
```

- `primary` teal for the single main action per view; `secondary` navy on light grounds; `accent` yellow only on navy/teal grounds; `danger` coral for withdraw/cancel.
- `outline`/`ghost` for secondary actions inside cards — they fill with `--surface-brand-soft` on hover and never lift.
- Never place two `primary` buttons side by side. Label with an imperative verb, 1–3 Arabic words.
