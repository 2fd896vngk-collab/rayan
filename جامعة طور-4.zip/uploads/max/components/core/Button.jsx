import React from "react";

const PALETTE = {
  primary:{bg:"var(--tawr-teal-600)",bgHover:"var(--tawr-teal-700)",bgPress:"var(--tawr-teal-800)",fg:"var(--text-on-brand)",border:"transparent",shadow:"var(--shadow-brand)"},
  secondary:{bg:"var(--tawr-navy-600)",bgHover:"var(--tawr-navy-700)",bgPress:"var(--tawr-navy-800)",fg:"var(--text-on-ink)",border:"transparent",shadow:"var(--shadow-md)"},
  accent:{bg:"var(--tawr-yellow-500)",bgHover:"var(--tawr-yellow-600)",bgPress:"var(--tawr-yellow-700)",fg:"var(--text-on-accent)",border:"transparent",shadow:"var(--shadow-accent)"},
  danger:{bg:"var(--tawr-coral-500)",bgHover:"var(--tawr-coral-600)",bgPress:"var(--tawr-coral-700)",fg:"#fff",border:"transparent",shadow:"var(--shadow-md)"},
  outline:{bg:"transparent",bgHover:"var(--surface-brand-soft)",bgPress:"var(--tawr-teal-200)",fg:"var(--text-brand)",border:"var(--tawr-teal-600)",shadow:"none"},
  ghost:{bg:"transparent",bgHover:"var(--surface-brand-soft)",bgPress:"var(--tawr-teal-200)",fg:"var(--text-brand)",border:"transparent",shadow:"none"}
};
const SIZES = {
  sm:{h:"var(--control-h-sm)",px:"16px",fs:"var(--fs-body-sm)"},
  md:{h:"var(--control-h)",px:"22px",fs:"var(--fs-body)"},
  lg:{h:"var(--control-h-lg)",px:"28px",fs:"var(--fs-body-lg)"}
};

export function Button({variant="primary",size="md",iconStart,iconEnd,fullWidth,disabled,children,onClick,type="button",style:styleOverride,...rest}){
  const [hover,setHover]=React.useState(false);
  const [press,setPress]=React.useState(false);
  const p=PALETTE[variant]||PALETTE.primary, s=SIZES[size]||SIZES.md;
  const style={
    display:"inline-flex",alignItems:"center",justifyContent:"center",gap:"var(--space-2)",
    height:s.h,padding:`0 ${s.px}`,width:fullWidth?"100%":undefined,
    font:`var(--fw-bold) ${s.fs}/1 var(--font-text)`,
    color:disabled?"var(--text-muted)":p.fg,background:disabled?"var(--surface-sunken)":press?p.bgPress:hover?p.bgHover:p.bg,
    border:`var(--stroke) solid ${disabled?"transparent":p.border}`,
    borderRadius:"var(--radius-control)",cursor:disabled?"not-allowed":"pointer",
    opacity:disabled?.72:1,
    boxShadow:disabled||variant==="ghost"||variant==="outline"?"none":press?"var(--shadow-xs)":hover?p.shadow:"var(--shadow-sm)",
    transform:disabled?"none":press?`scale(var(--press-scale))`:hover?"translateY(var(--hover-lift))":"none",
    transition:"var(--transition-control)",whiteSpace:"nowrap",...styleOverride
  };
  return React.createElement("button",{type,disabled,onClick,style,
    onMouseEnter:()=>setHover(true),onMouseLeave:()=>{setHover(false);setPress(false)},
    onMouseDown:()=>setPress(true),onMouseUp:()=>setPress(false),...rest},
    iconStart,children,iconEnd);
}
