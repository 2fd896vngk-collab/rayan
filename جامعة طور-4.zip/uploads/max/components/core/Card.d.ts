import * as React from "react";

/**
 * The system's container: white on paper, 18px radius, no border — separation comes from a soft navy-tinted shadow.
 * @startingPoint section="Core" subtitle="Card surfaces, accents and tones" viewport="700x220"
 */
export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  /** 4px top-edge bar, normally a faculty colour token */
  accent?: string;
  /** Adds hover lift + shadow step and a pointer cursor */
  interactive?: boolean;
  padding?: string;
  tone?: "paper" | "ink" | "brand" | "soft";
  /** URL of the chevron mark, drawn as an 8%-opacity watermark bottom-start */
  watermark?: string;
  children?: React.ReactNode;
}
export declare function Card(props: CardProps): JSX.Element;
