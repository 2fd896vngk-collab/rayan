import * as React from "react";

/**
 * Primary action control. Pill-shaped, brand-coloured, lifts on hover and scales to 0.97 on press.
 * @startingPoint section="Core" subtitle="Pill buttons in every brand variant" viewport="700x150"
 */
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** primary = teal (default), secondary = navy, accent = yellow, danger = coral, outline/ghost = teal on tint */
  variant?: "primary" | "secondary" | "accent" | "danger" | "outline" | "ghost";
  size?: "sm" | "md" | "lg";
  /** Leading icon node (Lucide `<i data-lucide>` or svg) — sits on the right in RTL */
  iconStart?: React.ReactNode;
  iconEnd?: React.ReactNode;
  fullWidth?: boolean;
  disabled?: boolean;
  children?: React.ReactNode;
}
export declare function Button(props: ButtonProps): JSX.Element;
