import React from "react";

const TONES={brand:["var(--surface-brand-soft)","var(--tawr-teal-800)"],
  success:["var(--status-success-soft)","var(--status-success)"],
  warning:["var(--status-warning-soft)","var(--tawr-yellow-700)"],
  danger:["var(--status-danger-soft)","var(--status-danger)"],
  info:["var(--status-info-soft)","var(--status-info)"],
  solid:["var(--tawr-navy-600)","#fff"]};

export function Badge({children,tone="brand",dot,solid,...rest}){
  const [bg,fg]=TONES[tone]||TONES.brand;
  return React.createElement("span",{style:{display:"inline-flex",alignItems:"center",gap:"var(--space-2)",
    background:solid?fg:bg,color:solid?"#fff":fg,borderRadius:"var(--radius-pill)",
    padding:"5px 12px",font:"var(--type-caption)",fontWeight:"var(--fw-bold)",whiteSpace:"nowrap"},...rest},
    dot?React.createElement("span",{style:{width:7,height:7,borderRadius:"50%",background:solid?"#fff":fg}}):null,
    children);
}
