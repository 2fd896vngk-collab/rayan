One-line: outlined filter chip; the selected state fills with the tag's own colour.

```jsx
<Tag color="var(--faculty-quran)" selected onClick={pick}>القرآن وعلومه</Tag>
```

Use in horizontal RTL rows with `gap: var(--space-2)`. Distinguish from `Badge`: Tag is interactive, Badge is read-only.
