import React from "react";

export function Card({children,accent,interactive,padding="var(--card-pad)",tone="paper",watermark,style,onClick,...rest}){
  const [hover,setHover]=React.useState(false);
  const tones={paper:{bg:"var(--surface-card)",fg:"var(--text-body)"},
    ink:{bg:"var(--surface-ink)",fg:"var(--text-on-ink)"},
    brand:{bg:"var(--surface-brand)",fg:"#fff"},
    soft:{bg:"var(--surface-brand-soft)",fg:"var(--text-body)"}};
  const t=tones[tone]||tones.paper;
  return React.createElement("div",{onClick,
    onMouseEnter:()=>setHover(true),onMouseLeave:()=>setHover(false),
    style:{position:"relative",overflow:"hidden",background:t.bg,color:t.fg,
      borderRadius:"var(--radius-card)",padding,
      boxShadow:interactive&&hover?"var(--shadow-md)":"var(--shadow-sm)",
      transform:interactive&&hover?"translateY(var(--hover-lift))":"none",
      cursor:interactive?"pointer":undefined,
      transition:"box-shadow var(--dur-base) var(--ease-standard),transform var(--dur-base) var(--ease-standard)",
      ...style},...rest},
    accent?React.createElement("span",{style:{position:"absolute",insetInline:0,top:0,height:4,background:accent}}):null,
    watermark?React.createElement("img",{src:watermark,alt:"",style:{position:"absolute",left:-18,bottom:-14,width:120,opacity:.08,pointerEvents:"none"}}):null,
    children);
}
