import * as React from "react";

/** Outlined chip for filters and taxonomies (colleges, levels, semesters). Fills solid when selected. */
export interface TagProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Border/text colour — pass a faculty or level token */
  color?: string;
  selected?: boolean;
  onRemove?: () => void;
  children?: React.ReactNode;
}
export declare function Tag(props: TagProps): JSX.Element;
