One-line: circular icon-only control for toolbars, dismissals and anything over imagery.

```jsx
<IconButton tone="soft" size="md" label="إشعارات" icon={<i data-lucide="bell" />} />
```

- Always fully round. Always pass `label`.
- `glass` is the only tone allowed on top of a photo, and only with a protection gradient behind it.
