import React from "react";

export function ProgressBar({value=0,max=100,color="var(--tawr-teal-600)",height=10,label,showValue,segments}){
  const pct=Math.max(0,Math.min(100,(value/max)*100));
  const track=React.createElement("div",{style:{background:"var(--surface-sunken)",borderRadius:"var(--radius-pill)",
    height,overflow:"hidden",display:"flex",flexDirection:"row-reverse"}},
    segments?segments.map((s,i)=>React.createElement("div",{key:i,
      style:{width:`${(s.value/max)*100}%`,background:s.color,
        transition:`width var(--dur-slow) var(--ease-rise)`}})) :
    React.createElement("div",{style:{width:`${pct}%`,background:color,borderRadius:"var(--radius-pill)",
      transition:`width var(--dur-slow) var(--ease-rise)`}}));
  if(!label&&!showValue) return track;
  return React.createElement("div",{style:{display:"flex",flexDirection:"column",gap:"var(--space-2)",width:"100%"}},
    React.createElement("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"baseline"}},
      label?React.createElement("span",{style:{font:"var(--type-label)",color:"var(--text-strong)"}},label):null,
      showValue?React.createElement("span",{style:{font:"var(--type-caption)",color:"var(--text-muted)",fontFamily:"var(--font-mono)"}},`${Math.round(pct)}%`):null),
    track);
}
