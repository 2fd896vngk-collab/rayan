import * as React from "react";

/** Inline message block on a soft brand tint — never a floating toast (the system has none). */
export interface AlertProps {
  tone?: "info" | "success" | "warning" | "danger";
  title?: string;
  icon?: React.ReactNode;
  onClose?: () => void;
  children?: React.ReactNode;
}
export declare function Alert(props: AlertProps): JSX.Element;
