import React from "react";

const TONES={info:["var(--status-info-soft)","var(--status-info)"],
  success:["var(--status-success-soft)","var(--status-success)"],
  warning:["var(--status-warning-soft)","var(--tawr-yellow-700)"],
  danger:["var(--status-danger-soft)","var(--status-danger)"]};

export function Alert({tone="info",title,children,icon,onClose}){
  const [bg,fg]=TONES[tone]||TONES.info;
  return React.createElement("div",{role:"status",
    style:{display:"flex",gap:"var(--space-3)",background:bg,borderRadius:"var(--radius-md)",
      padding:"14px 16px",color:"var(--text-body)"}},
    icon?React.createElement("span",{style:{color:fg,display:"grid",flex:"0 0 auto",marginTop:1}},icon):null,
    React.createElement("div",{style:{flex:1,display:"flex",flexDirection:"column",gap:4}},
      title?React.createElement("strong",{style:{font:"var(--type-body-strong)",color:fg}},title):null,
      children?React.createElement("span",{style:{font:"var(--type-body)",fontSize:"var(--fs-body-sm)"}},children):null),
    onClose?React.createElement("button",{onClick:onClose,"aria-label":"إغلاق",
      style:{border:"none",background:"transparent",cursor:"pointer",color:fg,fontSize:16,lineHeight:1}},"×"):null);
}
