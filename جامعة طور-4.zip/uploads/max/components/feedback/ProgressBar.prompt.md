One-line: the program's completion metric — levels cleared, semester progress.

```jsx
<ProgressBar label="تقدّمك في الخطة" value={9} max={24} showValue />
```

Segmented form colours each cleared level with its own level token. Always fills right-to-left.
