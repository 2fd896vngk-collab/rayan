import * as React from "react";

export interface ProgressSegment { value: number; color: string }
/**
 * Level/plan completion bar. Fills from the start edge (right, in RTL) over --dur-slow with --ease-rise.
 * @startingPoint section="Feedback" subtitle="Progress bars, segmented and single" viewport="700x180"
 */
export interface ProgressBarProps {
  value?: number;
  max?: number;
  color?: string;
  height?: number;
  label?: string;
  showValue?: boolean;
  /** Multi-colour breakdown, e.g. one segment per completed level */
  segments?: ProgressSegment[];
}
export declare function ProgressBar(props: ProgressBarProps): JSX.Element;
