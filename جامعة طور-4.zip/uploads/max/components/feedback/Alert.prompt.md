One-line: inline notice inside a page or card — deadlines, results, blocked actions.

```jsx
<Alert tone="warning" title="لم تُجتَز كل الكليات" icon={<i data-lucide="triangle-alert" />}>
  يجب اجتياز المستوى الأول من كل كلية قبل التخصص.
</Alert>
```

Soft tints only; no borders, no drop shadow. One alert per view.
