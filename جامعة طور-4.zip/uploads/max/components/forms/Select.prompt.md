One-line: dropdown for closed sets — college, level, semester.

```jsx
<Select label="الكلية" placeholder="اختر كلية" options={colleges} />
```

Six options or fewer? Prefer a `Tag` row. Use `Select` when the list grows or space is tight.
