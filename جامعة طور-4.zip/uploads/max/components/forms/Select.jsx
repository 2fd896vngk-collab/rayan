import React from "react";

export function Select({label,hint,options=[],value,onChange,placeholder,disabled,id,...rest}){
  const [focus,setFocus]=React.useState(false);
  const selectId=id||React.useId();
  return React.createElement("label",{htmlFor:selectId,style:{display:"flex",flexDirection:"column",gap:"var(--space-2)",width:"100%",minWidth:0}},
    label?React.createElement("span",{style:{font:"var(--type-label)",color:"var(--text-strong)"}},label):null,
    React.createElement("span",{style:{position:"relative",display:"block"}},
      React.createElement("select",{id:selectId,value,onChange,disabled,
        onFocus:()=>setFocus(true),onBlur:()=>setFocus(false),
        style:{width:"100%",height:"var(--control-h)",padding:"0 14px",appearance:"none",
          background:disabled?"var(--surface-sunken)":"var(--surface-card)",
          border:`var(--stroke) solid ${focus?"var(--tawr-teal-600)":"var(--border-default)"}`,
          borderRadius:"var(--radius-input)",font:"var(--type-body)",color:"var(--text-strong)",
          cursor:disabled?"not-allowed":"pointer"},...rest},
        placeholder?React.createElement("option",{value:"",disabled:true},placeholder):null,
        options.map(o=>React.createElement("option",{key:o.value,value:o.value},o.label))),
      React.createElement("svg",{width:18,height:18,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",
        strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",
        style:{position:"absolute",left:14,top:"50%",transform:"translateY(-50%)",pointerEvents:"none",color:"var(--text-muted)"}},
        React.createElement("path",{d:"m6 9 6 6 6-6"}))),
    hint?React.createElement("span",{style:{font:"var(--type-caption)",color:"var(--text-muted)"}},hint):null);
}
