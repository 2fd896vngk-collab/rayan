import React from "react";

export function Switch({label,checked,onChange,disabled,...rest}){
  return React.createElement("label",{style:{display:"inline-flex",alignItems:"center",gap:"var(--space-3)",
    cursor:disabled?"not-allowed":"pointer",opacity:disabled?.4:1}},
    React.createElement("span",{role:"switch","aria-checked":!!checked,
      onClick:()=>!disabled&&onChange&&onChange(!checked),
      style:{width:46,height:26,borderRadius:"var(--radius-pill)",padding:3,
        background:checked?"var(--tawr-teal-600)":"var(--tawr-navy-200)",
        display:"flex",justifyContent:checked?"flex-start":"flex-end",
        transition:"background-color var(--dur-fast) var(--ease-standard)"},...rest},
      React.createElement("span",{style:{width:20,height:20,borderRadius:"50%",background:"#fff",
        boxShadow:"var(--shadow-xs)",transition:"transform var(--dur-fast) var(--ease-standard)"}})),
    label?React.createElement("span",{style:{font:"var(--type-body-strong)",color:"var(--text-strong)"}},label):null);
}
