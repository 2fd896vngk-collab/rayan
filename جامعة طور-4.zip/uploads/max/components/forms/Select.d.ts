import * as React from "react";

export interface SelectOption { value: string; label: string }
/** Native select styled to match Input; caret sits on the left (RTL). */
export interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  hint?: string;
  options: SelectOption[];
  placeholder?: string;
}
export declare function Select(props: SelectProps): JSX.Element;
