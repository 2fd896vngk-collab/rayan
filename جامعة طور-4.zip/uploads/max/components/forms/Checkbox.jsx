import React from "react";

export function Checkbox({label,checked,onChange,disabled,description,...rest}){
  return React.createElement("label",{style:{display:"flex",gap:"var(--space-3)",alignItems:"flex-start",
    cursor:disabled?"not-allowed":"pointer",opacity:disabled?.4:1}},
    React.createElement("span",{style:{position:"relative",flex:"0 0 auto",width:22,height:22,marginTop:1,
      borderRadius:"var(--radius-xs)",
      border:`var(--stroke) solid ${checked?"var(--tawr-teal-600)":"var(--border-default)"}`,
      background:checked?"var(--tawr-teal-600)":"var(--surface-card)",
      boxShadow:checked?"none":"var(--shadow-inset)",
      transition:"var(--transition-control)"}},
      React.createElement("input",{type:"checkbox",checked:!!checked,onChange,disabled,
        style:{position:"absolute",inset:0,opacity:0,margin:0,cursor:"inherit",width:"100%",height:"100%"},...rest}),
      checked?React.createElement("span",{style:{position:"absolute",top:4,left:6,width:8,height:4,
        borderInline:"none",borderTop:"none",borderInlineStart:"2px solid #fff",borderBottom:"2px solid #fff",
        transform:"rotate(-45deg)"}}):null),
    React.createElement("span",{style:{display:"flex",flexDirection:"column",gap:2}},
      React.createElement("span",{style:{font:"var(--type-body-strong)",color:"var(--text-strong)"}},label),
      description?React.createElement("span",{style:{font:"var(--type-caption)",color:"var(--text-muted)"}},description):null));
}
