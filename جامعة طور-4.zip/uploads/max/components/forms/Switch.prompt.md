One-line: instant on/off setting — notifications, reminders.

```jsx
<Switch label="تنبيهات المستوى" checked={on} onChange={setOn} />
```

Use for settings that apply immediately. For anything needing a save action, use `Checkbox`.
