import * as React from "react";

/**
 * Labelled text field — 12px radius, 2px border that turns teal on focus, very light inner shadow.
 * @startingPoint section="Forms" subtitle="Text, select, checkbox and switch controls" viewport="700x300"
 */
export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  /** Helper text below the field */
  hint?: string;
  /** Error message — replaces hint and turns the border coral */
  error?: string;
  /** Leading icon node */
  icon?: React.ReactNode;
}
export declare function Input(props: InputProps): JSX.Element;
