One-line: multi-select and consent control.

```jsx
<Checkbox label="أوافق على شروط الالتحاق" description="تشمل الحضور والإشراف" checked={v} onChange={set} />
```
