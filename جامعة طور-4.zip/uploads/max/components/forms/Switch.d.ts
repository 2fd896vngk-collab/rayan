import * as React from "react";

/** Pill toggle for immediate settings. Knob sits at the start edge (right, in RTL) when on. */
export interface SwitchProps {
  label?: string;
  checked?: boolean;
  onChange?: (next: boolean) => void;
  disabled?: boolean;
}
export declare function Switch(props: SwitchProps): JSX.Element;
