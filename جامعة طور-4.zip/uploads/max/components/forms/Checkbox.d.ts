import * as React from "react";

/** 22px square with a 4px radius — the only near-square shape in the system. Fills teal when checked. */
export interface CheckboxProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  /** Secondary line under the label */
  description?: string;
}
export declare function Checkbox(props: CheckboxProps): JSX.Element;
