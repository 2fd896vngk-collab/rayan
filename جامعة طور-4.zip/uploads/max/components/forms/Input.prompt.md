One-line: the standard Arabic RTL text field, label above, hint or error below.

```jsx
<Input label="الاسم الكامل" placeholder="اكتب اسمك" icon={<i data-lucide="user" />} hint="كما هو في الهوية" />
```

Labels are noun phrases without a colon. Errors are a full short sentence: `الرجاء إدخال رقم جوال صحيح.`
