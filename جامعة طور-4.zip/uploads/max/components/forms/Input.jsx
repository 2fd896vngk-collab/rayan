import React from "react";

export function Input({label,hint,error,icon,type="text",value,onChange,placeholder,disabled,id,...rest}){
  const [focus,setFocus]=React.useState(false);
  const inputId=id||React.useId();
  const borderColor=error?"var(--status-danger)":focus?"var(--tawr-teal-600)":"var(--border-default)";
  return React.createElement("label",{htmlFor:inputId,style:{display:"flex",flexDirection:"column",gap:"var(--space-2)",width:"100%",minWidth:0}},
    label?React.createElement("span",{style:{font:"var(--type-label)",color:"var(--text-strong)"}},label):null,
    React.createElement("span",{style:{display:"flex",alignItems:"center",gap:"var(--space-2)",minWidth:0,
      height:"var(--control-h)",padding:"0 14px",background:disabled?"var(--surface-sunken)":"var(--surface-card)",
      border:`var(--stroke) solid ${borderColor}`,borderRadius:"var(--radius-input)",
      boxShadow:focus?"none":"var(--shadow-inset)",transition:"border-color var(--dur-fast) var(--ease-standard)"}},
      icon?React.createElement("span",{style:{color:"var(--text-muted)",display:"grid"}},icon):null,
      React.createElement("input",{id:inputId,type,value,onChange,placeholder,disabled,
        onFocus:()=>setFocus(true),onBlur:()=>setFocus(false),
        style:{flex:1,border:"none",outline:"none",background:"transparent",
          font:"var(--type-body)",color:"var(--text-strong)",minWidth:0},...rest})),
    error?React.createElement("span",{style:{font:"var(--type-caption)",color:"var(--status-danger)"}},error)
      :hint?React.createElement("span",{style:{font:"var(--type-caption)",color:"var(--text-muted)"}},hint):null);
}
