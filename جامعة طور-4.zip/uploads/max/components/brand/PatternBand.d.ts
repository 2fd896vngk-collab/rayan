import * as React from "react";

/**
 * Full-bleed chevron field section — the brand's signature background, always anchored to the bottom edge.
 * @startingPoint section="Brand" subtitle="Chevron field band with content over it" viewport="700x260"
 */
export interface PatternBandProps extends React.HTMLAttributes<HTMLDivElement> {
  src?: string;
  height?: number;
  /** Ground colour behind the pattern — must match the pattern asset's own ground */
  background?: string;
  opacity?: number;
  /** Mirror the field horizontally for variety across sections */
  flip?: boolean;
  children?: React.ReactNode;
}
export declare function PatternBand(props: PatternBandProps): JSX.Element;
