One-line: the college tile — always used in the 3×2 grid of six, never alone.

```jsx
<CollegeCard name="كلية التقنية" color="var(--faculty-tech)" levelsPassed={2}
  description="أربعة مستويات تبدأ من الدبلوم." icon={<i data-lucide="cpu" />} onClick={open} />
```

Colleges and colours are paired permanently — see `--faculty-*` in tokens/colors.css. Composes `Card`, `Badge`, `ProgressBar`.
