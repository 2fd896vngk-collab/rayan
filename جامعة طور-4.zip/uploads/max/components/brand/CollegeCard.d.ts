import * as React from "react";

/**
 * One of the six colleges, with its fixed accent colour and level progress. The 6-up grid of these is the brand's signature layout unit.
 * @startingPoint section="Brand" subtitle="The six-college grid card" viewport="700x260"
 */
export interface CollegeCardProps {
  name: string;
  /** A --faculty-* token; each college's colour is fixed */
  color?: string;
  levelsPassed?: number;
  levelsTotal?: number;
  description?: string;
  icon?: React.ReactNode;
  /** URL of the chevron mark for the 8% watermark */
  watermark?: string;
  status?: string;
  onClick?: () => void;
}
export declare function CollegeCard(props: CollegeCardProps): JSX.Element;
