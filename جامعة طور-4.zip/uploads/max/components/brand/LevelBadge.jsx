import React from "react";

const LEVELS={diploma:{label:"دبلوم",color:"var(--level-diploma)",fg:"var(--tawr-navy-700)",n:1},
  bachelor:{label:"بكالوريوس",color:"var(--level-bachelor)",fg:"#fff",n:2},
  master:{label:"ماجستير",color:"var(--level-master)",fg:"var(--tawr-navy-700)",n:3},
  phd:{label:"دكتوراه",color:"var(--level-phd)",fg:"#fff",n:4}};

export function LevelBadge({level="diploma",state="open",showNumber,size="md",color,textColor,numberColor}){
  const l=LEVELS[level]||LEVELS.diploma;
  const done=state==="passed", locked=state==="locked";
  const pad=size==="sm"?"5px 12px":"8px 16px";
  const fs=size==="sm"?"var(--fs-caption)":"var(--fs-body-sm)";
  return React.createElement("span",{style:{display:"inline-flex",alignItems:"center",gap:"var(--space-2)",
    padding:pad,borderRadius:"var(--radius-pill)",
    font:`var(--fw-bold) ${fs}/1 var(--font-display)`,
    background:locked?"var(--surface-sunken)":(color||l.color),
    color:locked?"var(--text-muted)":(textColor||l.fg),
    border:done?"var(--stroke) solid var(--tawr-navy-700)":"var(--stroke) solid transparent",
    opacity:locked?.75:1}},
    showNumber?React.createElement("span",{style:{width:18,height:18,borderRadius:"50%",
      background:locked?"var(--tawr-navy-200)":"rgba(255,255,255,.35)",display:"grid",placeItems:"center",
      fontSize:11,fontFamily:"var(--font-mono)",color:numberColor||undefined}},l.n):null,
    l.label,
    done?React.createElement("span",{style:{fontSize:11,opacity:.8}},"مجتاز"):null);
}
