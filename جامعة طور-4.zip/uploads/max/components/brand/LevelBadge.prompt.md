One-line: names a level anywhere it appears — never re-type the level names by hand.

```jsx
<LevelBadge level="master" state="locked" showNumber />
```

Level colours are fixed and non-negotiable: diploma pale teal, bachelor teal, master yellow, phd coral.
