One-line: the program's headline facts, set as big display numerals.

```jsx
<StatTile tone="brand" value="٦" label="كليات" sub="يجتاز الطالب المستوى الأول من كلٍّ منها" />
```

Use in rows of three or four. Mix at most one non-paper tone per row.
