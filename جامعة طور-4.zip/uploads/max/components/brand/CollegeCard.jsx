import React from "react";
import { Card } from "../core/Card.jsx";
import { ProgressBar } from "../feedback/ProgressBar.jsx";
import { Badge } from "../core/Badge.jsx";

export function CollegeCard({name,color="var(--faculty-sharia)",levelsPassed=0,levelsTotal=4,description,icon,watermark,onClick,status}){
  return React.createElement(Card,{accent:color,interactive:!!onClick,onClick,watermark,
    style:{display:"flex",flexDirection:"column",gap:"var(--space-3)"}},
    React.createElement("div",{style:{display:"flex",alignItems:"center",gap:"var(--space-3)"}},
      icon?React.createElement("span",{style:{width:44,height:44,borderRadius:"var(--radius-md)",
        background:color,color:"#fff",display:"grid",placeItems:"center",flex:"0 0 auto"}},icon):null,
      React.createElement("div",{style:{flex:1,minWidth:0}},
        React.createElement("h3",{style:{font:"var(--type-card-title)",color:"var(--text-strong)",margin:0}},name)),
      status?React.createElement(Badge,{tone:levelsPassed>=levelsTotal?"success":"info"},status):null),
    description?React.createElement("p",{style:{font:"var(--type-body)",color:"var(--text-body)",margin:0}},description):null,
    React.createElement("div",{style:{display:"flex",flexDirection:"column",gap:"var(--space-2)",marginTop:"auto"}},
      React.createElement("div",{style:{display:"flex",justifyContent:"space-between",font:"var(--type-caption)",color:"var(--text-muted)"}},
        React.createElement("span",null,"المستويات المجتازة"),
        React.createElement("span",{style:{fontFamily:"var(--font-mono)"}},`${levelsPassed}/${levelsTotal}`)),
      React.createElement(ProgressBar,{value:levelsPassed,max:levelsTotal,color,height:8})));
}
