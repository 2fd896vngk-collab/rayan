import * as React from "react";

/** Big-number tile for program facts — ٦ كليات، ٤ مستويات، ٦ فصول. Editorial contexts use Arabic-Indic numerals. */
export interface StatTileProps {
  value: React.ReactNode;
  label: string;
  sub?: string;
  tone?: "paper" | "brand" | "ink" | "accent";
  /** Explicit fill, overriding the tone */
  background?: string;
  /** Explicit colour for the sub line */
  subColor?: string;
  /** Explicit colour for the big value */
  valueColor?: string;
}
export declare function StatTile(props: StatTileProps): JSX.Element;
