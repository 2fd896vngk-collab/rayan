import React from "react";

export function StatTile({value,label,tone="paper",sub,background,subColor,valueColor}){
  const tones={paper:{bg:"var(--surface-card)",fg:"var(--text-strong)",sub:"var(--text-muted)",shadow:"var(--shadow-sm)"},
    brand:{bg:"var(--surface-brand)",fg:"#fff",sub:"rgba(255,255,255,.82)",shadow:"var(--shadow-brand)"},
    ink:{bg:"var(--surface-ink)",fg:"#fff",sub:"var(--tawr-navy-200)",shadow:"var(--shadow-md)"},
    accent:{bg:"var(--surface-accent)",fg:"var(--tawr-navy-700)",sub:"var(--tawr-navy-600)",shadow:"var(--shadow-accent)"}};
  const t=tones[tone]||tones.paper;
  return React.createElement("div",{style:{background:background||t.bg,color:t.fg,borderRadius:"var(--radius-card)",
    padding:"var(--card-pad)",boxShadow:t.shadow,display:"flex",flexDirection:"column",gap:4}},
    React.createElement("span",{style:{font:"var(--fw-extrabold) var(--fs-display-3)/1 var(--font-display)",color:valueColor||undefined}},value),
    React.createElement("span",{style:{font:"var(--type-label)"}},label),
    sub?React.createElement("span",{style:{font:"var(--type-caption)",color:subColor||t.sub}},sub):null);
}
