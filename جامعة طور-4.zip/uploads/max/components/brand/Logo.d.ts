import * as React from "react";

/**
 * The supplied طور wordmark / chevron mark as an image. The mark is never redrawn, recoloured or outlined.
 * @startingPoint section="Brand" subtitle="Wordmark and chevron mark on brand grounds" viewport="700x180"
 */
export interface LogoProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  /** wordmark = full colour on light, wordmark-on-dark = teal on navy, chevron = mark only */
  variant?: "wordmark" | "wordmark-on-dark" | "chevron";
  /** Override the asset path — required when assets/ sits elsewhere relative to the page */
  src?: string;
  height?: number;
}
export declare function Logo(props: LogoProps): JSX.Element;
