import React from "react";

/* Renders the SUPPLIED wordmark/chevron image assets. Never re-draw the mark.
   Copy assets/ into the consuming project and pass the correct relative src. */
export function Logo({variant="wordmark",src,height=40,alt="جامعة طور",style,...rest}){
  const defaults={wordmark:"assets/logo-wordmark-transparent.png",
    "wordmark-on-dark":"assets/logo-wordmark-on-navy.png",
    chevron:"assets/logo-chevron-mark.png"};
  return React.createElement("img",{src:src||defaults[variant]||defaults.wordmark,alt,
    style:{height,width:"auto",display:"block",...style},...rest});
}
