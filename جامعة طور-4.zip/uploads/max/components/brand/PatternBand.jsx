import React from "react";

/* Bottom-anchored chevron field, as it appears in the supplied banner and on the t-shirt hem. */
export function PatternBand({src="assets/pattern-chevrons-scatter.png",height=220,background="var(--tawr-navy-canvas)",opacity=1,flip,children,style,...rest}){
  return React.createElement("div",{style:{position:"relative",overflow:"hidden",background,minHeight:height,...style},...rest},
    React.createElement("img",{src,alt:"",style:{position:"absolute",insetInline:0,bottom:0,width:"100%",
      opacity,transform:flip?"scaleX(-1)":"none",pointerEvents:"none"}}),
    React.createElement("div",{style:{position:"relative"}},children));
}
