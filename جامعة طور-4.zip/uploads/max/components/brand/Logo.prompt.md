One-line: places the real brand mark; use it instead of typing "طور" as text wherever a logo belongs.

```jsx
<Logo variant="wordmark-on-dark" src="../../assets/logo-wordmark-on-dark.png" height={44} />
```

- Light grounds (white, yellow, teal, coral) → `wordmark`. Navy ground → `wordmark-on-dark`.
- Clear space around the mark is at least the height of its chevron. Minimum height 28px.
- In RTL layouts the logo sits at the top-**right**.
