One-line: the chevron-field section — footers, page tops, CTA bands.

```jsx
<PatternBand src="../../assets/pattern-chevrons-navy-on-yellow.png" height={260}>
  <h2>ابدأ رحلتك في طور</h2>
</PatternBand>
```

Pattern always hugs the bottom and bleeds off both sides. Keep text in the upper half; drop `opacity` to ~0.35 if text must overlap.
