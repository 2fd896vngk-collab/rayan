import * as React from "react";

/**
 * The four academic levels with their fixed colours: دبلوم / بكالوريوس / ماجستير / دكتوراة.
 * @startingPoint section="Brand" subtitle="The four level badges and their states" viewport="700x150"
 */
export interface LevelBadgeProps {
  level?: "diploma" | "bachelor" | "master" | "phd";
  /** open = available, passed = cleared (outlined), locked = greyed to the sunken surface */
  state?: "open" | "passed" | "locked";
  /** Shows the level ordinal 1–4 in a circle */
  showNumber?: boolean;
  size?: "sm" | "md";
  /** Override the level's fixed fill colour */
  color?: string;
  /** Override the label colour — required when `color` is a dark fill */
  textColor?: string;
  /** Override the ordinal circle's text colour */
  numberColor?: string;
}
export declare function LevelBadge(props: LevelBadgeProps): JSX.Element;
