import React from "react";

export function Tabs({items=[],value,onChange,variant="pill"}){
  const isPill=variant==="pill";
  return React.createElement("div",{role:"tablist",
    style:{display:"flex",gap:isPill?"var(--space-2)":"var(--space-6)",
      background:isPill?"var(--surface-sunken)":"transparent",
      padding:isPill?"5px":0,borderRadius:"var(--radius-pill)",
      borderBottom:isPill?"none":"1px solid var(--border-subtle)",width:"fit-content",maxWidth:"100%"}},
    items.map(it=>{
      const active=it.value===value;
      return React.createElement("button",{key:it.value,role:"tab","aria-selected":active,
        onClick:()=>onChange&&onChange(it.value),
        style:{border:"none",cursor:"pointer",whiteSpace:"nowrap",
          font:`${active?"var(--fw-bold)":"var(--fw-medium)"} var(--fs-body-sm)/1 var(--font-text)`,
          color:active?(isPill?"var(--text-on-brand)":"var(--text-brand)"):"var(--text-muted)",
          background:isPill?(active?"var(--tawr-teal-600)":"transparent"):"transparent",
          borderRadius:"var(--radius-pill)",padding:isPill?"10px 18px":"0 0 12px",
          borderBottom:isPill?"none":`var(--stroke-thick) solid ${active?"var(--tawr-teal-600)":"transparent"}`,
          transition:"var(--transition-control)"}},
        it.label,
        it.count!=null?React.createElement("span",{style:{marginInlineStart:6,opacity:.7}},it.count):null);
    }));
}
