import * as React from "react";

export interface TabItem { value: string; label: string; count?: number }
/**
 * Horizontal RTL section switcher — pill group on a sunken track, or an underline row.
 * @startingPoint section="Navigation" subtitle="Pill and underline tab rows" viewport="700x140"
 */
export interface TabsProps {
  items: TabItem[];
  value: string;
  onChange?: (value: string) => void;
  variant?: "pill" | "underline";
}
export declare function Tabs(props: TabsProps): JSX.Element;
