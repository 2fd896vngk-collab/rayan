One-line: switch between sibling views — levels within a college, semesters within the plan.

```jsx
<Tabs variant="pill" value={tab} onChange={setTab} items={[{value:"d",label:"دبلوم"},{value:"b",label:"بكالوريوس"}]} />
```

`pill` inside cards and app screens; `underline` for page-level sections on the website. Tabs flow right-to-left.
