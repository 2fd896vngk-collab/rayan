const { Button, Input, Select, Badge, Tag, Alert, ProgressBar, IconButton } = window.TawrUniversityDesignSystem_40b441;

/* خانة التحضير: المشرف يضيف برامج، ويحضّر الطلاب في كل برنامج. */
function AttendanceScreen() {
  const { colleges } = window.TAWR;
  const [programs,setPrograms] = React.useState([
    { id:1, name:"حلقة القرآن الأسبوعية", college:"quran", day:"الأحد", time:"17:00", students:[
      { n:"عبدالله المطيري", s:"present" },{ n:"سعد الحربي", s:"present" },
      { n:"محمد العتيبي", s:"late" },{ n:"يوسف الشمري", s:"absent" },
      { n:"تركي القحطاني", s:"present" }
    ]},
    { id:2, name:"ورشة البرمجة", college:"tech", day:"الثلاثاء", time:"19:00", students:[
      { n:"عبدالله المطيري", s:"present" },{ n:"سعد الحربي", s:"absent" },
      { n:"محمد العتيبي", s:"present" },{ n:"يوسف الشمري", s:"present" }
    ]},
    { id:3, name:"لقاء القيادة (اختياري)", college:"skills", day:"الخميس", time:"18:30", students:[
      { n:"سعد الحربي", s:"present" },{ n:"تركي القحطاني", s:"late" }
    ]}
  ]);
  const [activeId,setActiveId] = React.useState(1);
  const [adding,setAdding] = React.useState(false);
  const [form,setForm] = React.useState({ name:"", college:"quran", day:"الأحد", time:"17:00" });
  const active = programs.find(p=>p.id===activeId) || programs[0];
  const colorOf = id => (colleges.find(c=>c.id===id)||{}).color || "var(--tawr-teal-600)";
  const nameOf  = id => (colleges.find(c=>c.id===id)||{}).name || "";

  const setState = (i,s) => setPrograms(ps=>ps.map(p=>p.id!==active.id?p:
    {...p, students:p.students.map((st,idx)=>idx===i?{...st,s}:st)}));

  const addProgram = () => {
    if(!form.name.trim()) return;
    const id = Math.max(0,...programs.map(p=>p.id))+1;
    setPrograms(ps=>[...ps,{ ...form, id, name:form.name.trim(), students:[
      { n:"عبدالله المطيري", s:"none" },{ n:"سعد الحربي", s:"none" },
      { n:"محمد العتيبي", s:"none" },{ n:"يوسف الشمري", s:"none" }
    ]}]);
    setActiveId(id); setAdding(false); setForm({ name:"", college:"quran", day:"الأحد", time:"17:00" });
  };

  const counts = active.students.reduce((a,s)=>({...a,[s.s]:(a[s.s]||0)+1}),{});
  const present = counts.present||0, late = counts.late||0, absent = counts.absent||0;
  const marked = present+late+absent;
  const STATES = [["present","حاضر","var(--tawr-teal-600)"],["late","متأخر","var(--tawr-yellow-500)"],["absent","غائب","var(--tawr-coral-500)"]];
  const dark = {"--text-strong":"var(--text-on-canvas)","--surface-card":"rgba(0,0,0,.2)","--border-default":"var(--border-canvas)","--text-muted":"var(--text-on-canvas-muted)"};

  return (
    <CanvasPage>
      <CanvasBackdrop opacity={.55} width={330}/>
      <main style={{position:"relative",maxWidth:"var(--container-max)",margin:"0 auto",padding:"var(--space-16) var(--container-pad) var(--space-20)"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-end",gap:"var(--space-8)",marginBottom:"var(--space-6)"}}>
          <div>
            <h1 style={{color:"var(--text-on-canvas)",marginBottom:"var(--space-2)"}}>التحضير</h1>
            <p style={{font:"var(--type-body)",color:"var(--text-on-canvas-muted)",maxWidth:"58ch",margin:0}}>
              يضيف المشرف البرامج، ثم يحضّر الطلاب في كل برنامج. البرامج الاختيارية تُعلَّم بذلك صراحةً.
            </p>
          </div>
          <Button variant="primary" onClick={()=>setAdding(a=>!a)} iconStart={<i data-lucide={adding?"x":"plus"}></i>}>
            {adding?"إلغاء":"أضف برنامجًا"}
          </Button>
        </div>

        {adding && (
          <DarkCard padding="var(--space-6)" strong style={{...dark,marginBottom:"var(--space-6)"}}>
            <h3 style={{color:"var(--text-on-canvas)",marginBottom:"var(--space-4)"}}>برنامج جديد</h3>
            <div style={{display:"grid",gridTemplateColumns:"2fr 1.2fr 1fr 1fr auto",gap:"var(--space-3)",alignItems:"end"}}>
              <Input label="اسم البرنامج" placeholder="مثال: حلقة القرآن الأسبوعية"
                value={form.name} onChange={e=>setForm({...form,name:e.target.value})} icon={<i data-lucide="calendar-plus"></i>}/>
              <Select label="الكلية" value={form.college} onChange={e=>setForm({...form,college:e.target.value})}
                options={colleges.map(c=>({value:c.id,label:c.name}))}/>
              <Select label="اليوم" value={form.day} onChange={e=>setForm({...form,day:e.target.value})}
                options={["الأحد","الاثنين","الثلاثاء","الأربعاء","الخميس"].map(d=>({value:d,label:d}))}/>
              <Input label="الوقت" type="time" value={form.time} onChange={e=>setForm({...form,time:e.target.value})}/>
              <Button variant="accent" onClick={addProgram}>أضف</Button>
            </div>
          </DarkCard>
        )}

        <div style={{display:"grid",gridTemplateColumns:"1fr 1.9fr",gap:"var(--gutter)",alignItems:"start"}}>
          <DarkCard padding="var(--space-5)">
            <h3 style={{color:"var(--text-on-canvas)",marginBottom:"var(--space-4)"}}>البرامج</h3>
            <div style={{display:"flex",flexDirection:"column",gap:"var(--space-2)"}}>
              {programs.map(p=>{
                const on = p.id===active.id;
                return (
                  <button key={p.id} onClick={()=>setActiveId(p.id)}
                    style={{textAlign:"start",cursor:"pointer",border:on?"var(--stroke) solid "+colorOf(p.college):"1px solid var(--border-canvas)",
                      background:on?"rgba(255,255,255,.1)":"transparent",borderRadius:"var(--radius-md)",
                      padding:"var(--space-3) var(--space-4)",display:"flex",flexDirection:"column",gap:4,
                      transition:"var(--transition-control)"}}>
                    <span style={{display:"flex",alignItems:"center",gap:"var(--space-2)"}}>
                      <span style={{width:8,height:8,borderRadius:"50%",background:colorOf(p.college),flex:"0 0 auto"}}/>
                      <span style={{font:"var(--type-body-strong)",color:"var(--text-on-canvas)"}}>{p.name}</span>
                    </span>
                    <span style={{font:"var(--type-caption)",color:"var(--text-on-canvas-muted)"}}>
                      {nameOf(p.college)} · {p.day} {p.time} · {p.students.length} طالبًا
                    </span>
                  </button>
                );
              })}
            </div>
          </DarkCard>

          <div style={{display:"flex",flexDirection:"column",gap:"var(--gutter)"}}>
            <DarkCard accent={colorOf(active.college)} padding="var(--space-6)">
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",gap:"var(--space-4)",marginBottom:"var(--space-5)"}}>
                <div>
                  <h2 style={{fontSize:"var(--fs-title-2)",color:"var(--text-on-canvas)"}}>{active.name}</h2>
                  <p style={{font:"var(--type-body)",color:"var(--text-on-canvas-muted)",margin:"4px 0 0"}}>
                    {nameOf(active.college)} · {active.day} · {active.time}
                  </p>
                </div>
                <div style={{display:"flex",gap:"var(--space-2)"}}>
                  <Badge tone="success">حاضر {present}</Badge>
                  <Badge tone="warning">متأخر {late}</Badge>
                  <Badge tone="danger">غائب {absent}</Badge>
                </div>
              </div>

              <div style={{marginBottom:"var(--space-5)"}}>
                <ProgressBar label="نسبة التحضير" value={marked} max={active.students.length} showValue color={colorOf(active.college)}/>
              </div>

              <div style={{display:"flex",flexDirection:"column",gap:"var(--space-2)"}}>
                {active.students.map((st,i)=>(
                  <div key={st.n} style={{display:"flex",alignItems:"center",gap:"var(--space-3)",
                    background:"rgba(0,0,0,.16)",borderRadius:"var(--radius-md)",padding:"var(--space-3) var(--space-4)"}}>
                    <span style={{width:34,height:34,borderRadius:"50%",background:"rgba(255,255,255,.1)",
                      display:"grid",placeItems:"center",font:"var(--type-label)",color:"var(--text-on-canvas)",flex:"0 0 auto"}}>
                      {st.n.slice(0,1)}
                    </span>
                    <span style={{flex:1,font:"var(--type-body-strong)",color:"var(--text-on-canvas)"}}>{st.n}</span>
                    <span style={{display:"flex",gap:"var(--space-2)"}}>
                      {STATES.map(([key,label,color])=>{
                        const on = st.s===key;
                        return (
                          <button key={key} onClick={()=>setState(i,key)}
                            style={{cursor:"pointer",borderRadius:"var(--radius-pill)",padding:"6px 14px",
                              font:"var(--type-label)",whiteSpace:"nowrap",
                              border:"var(--stroke) solid "+(on?color:"var(--border-canvas)"),
                              background:on?color:"transparent",
                              color:on?(key==="late"?"var(--tawr-navy-700)":"#fff"):"var(--text-on-canvas-muted)",
                              transition:"var(--transition-control)"}}>{label}</button>
                        );
                      })}
                    </span>
                  </div>
                ))}
              </div>
            </DarkCard>

            {marked<active.students.length && (
              <Alert tone="warning" title="التحضير غير مكتمل" icon={<i data-lucide="triangle-alert"></i>}>
                بقي {active.students.length-marked} طالبًا دون تحضير في هذا البرنامج.
              </Alert>
            )}
          </div>
        </div>
      </main>
    </CanvasPage>
  );
}

Object.assign(window, { AttendanceScreen });
