const { Button, Input, Select, Badge, Alert, ProgressBar, Tabs } = window.TawrUniversityDesignSystem_40b441;

/* لوحة المشرف: التحضير، إضافة المهام، ومتابعة مهام الطلاب. */
const SUP_STUDENTS = ["عبدالله المطيري","سعد الحربي","محمد العتيبي","يوسف الشمري","تركي القحطاني"];

function SupPanel({ title, subtitle, action, children }) {
  return (
    <DarkCard padding="var(--space-6)">
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",gap:"var(--space-4)",marginBottom:"var(--space-5)"}}>
        <div>
          <h2 style={{fontSize:"var(--fs-title-2)",color:"var(--text-on-canvas)"}}>{title}</h2>
          {subtitle && <p style={{font:"var(--type-body)",color:"var(--text-on-canvas-muted)",margin:"4px 0 0",maxWidth:"58ch"}}>{subtitle}</p>}
        </div>
        {action}
      </div>
      {children}
    </DarkCard>
  );
}

function SupervisorScreen({ go }) {
  const dark = {"--text-strong":"var(--text-on-canvas)","--surface-card":"rgba(255,255,255,.06)","--surface-sunken":"rgba(0,0,0,.28)","--border-default":"var(--border-canvas)","--text-muted":"var(--text-on-canvas-muted)"};
  const [tab,setTab] = React.useState("attend");

  /* التحضير */
  const [roll,setRoll] = React.useState(SUP_STUDENTS.map(n=>({n,s:"none"})));
  const [session,setSession] = React.useState("حلقة القرآن الأسبوعية");
  const STATES = [["present","حاضر","var(--tawr-teal-600)"],["late","متأخر","var(--tawr-yellow-500)"],["absent","غائب","var(--tawr-coral-500)"]];
  const cnt = k => roll.filter(r=>r.s===k).length;
  const marked = roll.length - cnt("none");

  /* المهام */
  const [tasks,setTasks] = React.useState([
    { id:1, title:"حفظ سورة الملك", due:"2026-09-05", college:"القرآن", assignees:5, submitted:4, graded:2 },
    { id:2, title:"مشروع صفحة ويب بسيطة", due:"2026-09-12", college:"التقنية", assignees:5, submitted:2, graded:0 },
    { id:3, title:"تقرير قراءة كتاب", due:"2026-09-18", college:"المهارات", assignees:5, submitted:5, graded:5 }
  ]);
  const [form,setForm] = React.useState({ title:"", due:"", college:"القرآن", note:"" });
  const addTask = () => {
    if(!form.title.trim()) return;
    setTasks(ts=>[...ts,{ id:Math.max(0,...ts.map(t=>t.id))+1, title:form.title.trim(), due:form.due||"—",
      college:form.college, assignees:SUP_STUDENTS.length, submitted:0, graded:0 }]);
    setForm({ title:"", due:"", college:"القرآن", note:"" });
    setTab("follow");
  };

  /* المتابعة */
  const [followId,setFollowId] = React.useState(1);
  const [subs,setSubs] = React.useState(()=>{
    const o = {};
    [1,2,3].forEach(id=>{ o[id] = SUP_STUDENTS.map((n,i)=>({ n, s: i<(id===1?4:id===2?2:5) ? (i<(id===1?2:id===3?5:0)?"graded":"submitted") : "pending" })); });
    return o;
  });
  const followRows = subs[followId] || SUP_STUDENTS.map(n=>({n,s:"pending"}));
  const SUB_TONE = { graded:["مُقيَّمة","var(--tawr-teal-600)"], submitted:["مُسلَّمة","var(--tawr-yellow-500)"], pending:["لم تُسلَّم","var(--tawr-coral-500)"] };
  const cycle = i => setSubs(o=>({ ...o, [followId]: followRows.map((r,idx)=>idx!==i?r:
    { ...r, s: r.s==="pending"?"submitted":r.s==="submitted"?"graded":"pending" }) }));

  return (
    <CanvasPage>
      <CanvasBackdrop opacity={.55} width={330}/>
      <main style={{position:"relative",maxWidth:"var(--container-max)",margin:"0 auto",padding:"var(--space-16) var(--container-pad) var(--space-20)"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-end",gap:"var(--space-8)",marginBottom:"var(--space-6)"}}>
          <div>
            <h1 style={{color:"var(--text-on-canvas)",marginBottom:"var(--space-2)"}}>لوحة المشرف</h1>
            <p style={{font:"var(--type-body)",color:"var(--text-on-canvas-muted)",maxWidth:"58ch",margin:0}}>
              تحضير الطلاب، إضافة المهام، ومتابعة تسليمها — في مكان واحد.
            </p>
          </div>
          <Badge tone="info">مشرف · كلية القرآن</Badge>
        </div>

        <div style={{...dark,marginBottom:"var(--space-6)"}}>
          <Tabs value={tab} onChange={setTab} items={[
            {value:"attend",label:"التحضير"},
            {value:"add",label:"إضافة مهام"},
            {value:"follow",label:"متابعة المهام"}
          ]}/>
        </div>

        {tab==="attend" && (
          <SupPanel title="خانة التحضير" subtitle="اختر الجلسة، ثم حدّد حالة كل طالب."
            action={<div style={{display:"flex",gap:"var(--space-2)"}}>
              <Badge tone="success">حاضر {cnt("present")}</Badge>
              <Badge tone="warning">متأخر {cnt("late")}</Badge>
              <Badge tone="danger">غائب {cnt("absent")}</Badge>
            </div>}>
            <div style={{...dark,display:"grid",gridTemplateColumns:"2fr 1fr",gap:"var(--space-4)",marginBottom:"var(--space-5)"}}>
              <Select label="الجلسة" value={session} onChange={e=>setSession(e.target.value)}
                options={["حلقة القرآن الأسبوعية","ورشة البرمجة","لقاء القيادة"].map(v=>({value:v,label:v}))}/>
              <Input label="التاريخ" type="date" defaultValue="2026-08-25"/>
            </div>
            <div style={{marginBottom:"var(--space-5)"}}>
              <ProgressBar label="نسبة التحضير" value={marked} max={roll.length} showValue/>
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:"var(--space-2)"}}>
              {roll.map((st,i)=>(
                <div key={st.n} style={{display:"flex",alignItems:"center",gap:"var(--space-3)",
                  background:"rgba(0,0,0,.16)",borderRadius:"var(--radius-md)",padding:"var(--space-3) var(--space-4)"}}>
                  <span style={{width:34,height:34,borderRadius:"50%",background:"rgba(255,255,255,.1)",
                    display:"grid",placeItems:"center",font:"var(--type-label)",color:"var(--text-on-canvas)",flex:"0 0 auto"}}>{st.n.slice(0,1)}</span>
                  <span style={{flex:1,font:"var(--type-body-strong)",color:"var(--text-on-canvas)"}}>{st.n}</span>
                  <span style={{display:"flex",gap:"var(--space-2)"}}>
                    {STATES.map(([key,label,color])=>{
                      const on = st.s===key;
                      return (
                        <button key={key} onClick={()=>setRoll(rs=>rs.map((r,idx)=>idx===i?{...r,s:key}:r))}
                          style={{cursor:"pointer",borderRadius:"var(--radius-pill)",padding:"6px 14px",font:"var(--type-label)",whiteSpace:"nowrap",
                            border:"var(--stroke) solid "+(on?color:"var(--border-canvas)"),background:on?color:"transparent",
                            color:on?(key==="late"?"var(--tawr-navy-700)":"#fff"):"var(--text-on-canvas-muted)",
                            transition:"var(--transition-control)"}}>{label}</button>
                      );
                    })}
                  </span>
                </div>
              ))}
            </div>
            {marked<roll.length && (
              <div style={{marginTop:"var(--space-5)"}}>
                <Alert tone="warning" title="التحضير غير مكتمل" icon={<i data-lucide="triangle-alert"></i>}>
                  بقي {roll.length-marked} طالبًا دون تحضير.
                </Alert>
              </div>
            )}
          </SupPanel>
        )}

        {tab==="add" && (
          <SupPanel title="خانة إضافة المهام" subtitle="أضف مهمة جديدة وحدّد الكلية وتاريخ التسليم.">
            <div style={{...dark,display:"grid",gridTemplateColumns:"2fr 1fr 1fr",gap:"var(--space-4)",alignItems:"end"}}>
              <Input label="عنوان المهمة" placeholder="مثال: حفظ سورة الملك"
                value={form.title} onChange={e=>setForm({...form,title:e.target.value})} icon={<i data-lucide="clipboard-list"></i>}/>
              <Select label="الكلية" value={form.college} onChange={e=>setForm({...form,college:e.target.value})}
                options={["القرآن","التقنية","المهارات","الرياضة","الإعلام"].map(v=>({value:v,label:v}))}/>
              <Input label="تاريخ التسليم" type="date" value={form.due} onChange={e=>setForm({...form,due:e.target.value})}/>
            </div>
            <div style={{...dark,marginTop:"var(--space-4)"}}>
              <Input label="تفاصيل (اختياري)" placeholder="اكتب وصفًا موجزًا للمهمة"
                value={form.note} onChange={e=>setForm({...form,note:e.target.value})}/>
            </div>
            <div style={{display:"flex",justifyContent:"flex-start",gap:"var(--space-3)",marginTop:"var(--space-5)"}}>
              <Button variant="accent" onClick={addTask} iconStart={<i data-lucide="plus"></i>}>أضف المهمة</Button>
              <Button variant="ghost" onClick={()=>setForm({ title:"", due:"", college:"القرآن", note:"" })}>تفريغ</Button>
            </div>
            <p style={{font:"var(--type-caption)",color:"var(--text-on-canvas-muted)",margin:"var(--space-4) 0 0"}}>
              ستُسنَد المهمة تلقائيًا إلى {SUP_STUDENTS.length} طلاب في الكلية المختارة.
            </p>
          </SupPanel>
        )}

        {tab==="follow" && (
          <div style={{display:"grid",gridTemplateColumns:"1fr 1.9fr",gap:"var(--gutter)",alignItems:"start"}}>
            <DarkCard padding="var(--space-5)">
              <h3 style={{color:"var(--text-on-canvas)",marginBottom:"var(--space-4)"}}>المهام</h3>
              <div style={{display:"flex",flexDirection:"column",gap:"var(--space-2)"}}>
                {tasks.map(t=>{
                  const on = t.id===followId;
                  return (
                    <button key={t.id} onClick={()=>setFollowId(t.id)}
                      style={{textAlign:"start",cursor:"pointer",
                        border:on?"var(--stroke) solid var(--tawr-teal-600)":"1px solid var(--border-canvas)",
                        background:on?"rgba(255,255,255,.1)":"transparent",borderRadius:"var(--radius-md)",
                        padding:"var(--space-3) var(--space-4)",display:"flex",flexDirection:"column",gap:4,
                        transition:"var(--transition-control)"}}>
                      <span style={{font:"var(--type-body-strong)",color:"var(--text-on-canvas)"}}>{t.title}</span>
                      <span style={{font:"var(--type-caption)",color:"var(--text-on-canvas-muted)"}}>
                        {t.college} · التسليم {t.due} · {t.submitted}/{t.assignees} سلّموا
                      </span>
                    </button>
                  );
                })}
              </div>
            </DarkCard>

            <SupPanel title="خانة متابعة مهام الطلاب" subtitle="اضغط على حالة الطالب لتغييرها: لم تُسلَّم ← مُسلَّمة ← مُقيَّمة.">
              <div style={{marginBottom:"var(--space-5)"}}>
                <ProgressBar label="نسبة التسليم" showValue
                  value={followRows.filter(r=>r.s!=="pending").length} max={followRows.length}/>
              </div>
              <div style={{display:"flex",flexDirection:"column",gap:"var(--space-2)"}}>
                {followRows.map((r,i)=>{
                  const [label,color] = SUB_TONE[r.s];
                  return (
                    <div key={r.n} style={{display:"flex",alignItems:"center",gap:"var(--space-3)",
                      background:"rgba(0,0,0,.16)",borderRadius:"var(--radius-md)",padding:"var(--space-3) var(--space-4)"}}>
                      <span style={{width:34,height:34,borderRadius:"50%",background:"rgba(255,255,255,.1)",
                        display:"grid",placeItems:"center",font:"var(--type-label)",color:"var(--text-on-canvas)",flex:"0 0 auto"}}>{r.n.slice(0,1)}</span>
                      <span style={{flex:1,font:"var(--type-body-strong)",color:"var(--text-on-canvas)"}}>{r.n}</span>
                      <button onClick={()=>cycle(i)}
                        style={{cursor:"pointer",borderRadius:"var(--radius-pill)",padding:"6px 16px",font:"var(--type-label)",whiteSpace:"nowrap",
                          border:"var(--stroke) solid "+color,background:color,
                          color:r.s==="submitted"?"var(--tawr-navy-700)":"#fff",transition:"var(--transition-control)"}}>{label}</button>
                    </div>
                  );
                })}
              </div>
            </SupPanel>
          </div>
        )}
      </main>
    </CanvasPage>
  );
}

Object.assign(window, { SupervisorScreen, SupPanel });
