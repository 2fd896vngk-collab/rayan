# UI kit — جامعة طور program website (RTL)

Public-facing site for the program. **No original product UI, Figma file or codebase was supplied**, so this is a brand-faithful construction from the supplied assets (palette, chevron field, monoline wordmark, dark editorial poster idiom) — not a recreation of an existing site. Re-cut it against real screens when they exist.

## Screens
| File | Surface |
|---|---|
| `Chrome.screen.jsx` | `SiteHeader` (glass navy, logo top-right, yellow active underline) + `SiteFooter` (navy, college list, `#اللجنة_الإعلامية` signature) |
| `Home.screen.jsx` | Hero on the navy canvas with the chevron field at the start edge, stat row, six-college grid, four-level explainer, chevron-field CTA |
| `Colleges.screen.jsx` | College picker (Tag row) → college detail with level tabs and unit list, level states sidebar |
| `Plan.screen.jsx` | The four levels as a vertical timeline, plus per-college progress |
| `Attendance.screen.jsx` | التحضير — supervisor adds programs, then marks each student حاضر / متأخر / غائب |
| `Signup.screen.jsx` | التسجيل — two-column signup: brand panel with a 3-step tracker + merged enrollment form (details, required college, optional college, consent) and a success state |

`data.js` holds the five colleges, four levels and the four level stages as `window.TAWR`.

## Interaction
Header nav switches screens; college tags filter the detail card; level tabs swap the unit list; the signup form validates on the consent checkbox and the required-college pick, then flips to a confirmation state; the attendance screen adds programs and toggles per-student states.

## Canvas
`Chrome.screen.jsx` exports the shared shell: `CanvasPage` (navy ground), `CanvasBackdrop` (the chevron field as a fixed-width, vertically repeating, right-fading column), `DarkCard` (translucent white panel) and `SectionHead`. Every screen composes those three, so the master brand composition is consistent across all four pages.

## Composition
Every control comes from `components/` via `window.TawrUniversityDesignSystem_40b441` — Button, IconButton, Card, Badge, Tag, Input, Select, Checkbox, Tabs, ProgressBar, Alert, Logo, PatternBand, LevelBadge, CollegeCard, StatTile. Nothing is re-implemented locally. Icons are Lucide (substitution — see readme.md ICONOGRAPHY).
