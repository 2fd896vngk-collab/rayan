const { Badge, ProgressBar, LevelBadge, Button, Alert } = window.TawrUniversityDesignSystem_40b441;

function PlanScreen({ go }) {
  const { stages, colleges, levels } = window.TAWR;
  const tone = { passed:"success", current:"warning", open:"info" };
  const label = { passed:"مجتاز", current:"الحالي", open:"لاحقًا" };
  return (
    <CanvasPage>
      <CanvasBackdrop opacity={.55} width={330}/>
      <main style={{position:"relative",maxWidth:"var(--container-max)",margin:"0 auto",padding:"var(--space-16) var(--container-pad) var(--space-20)"}}>
        <h1 style={{color:"var(--text-on-canvas)",marginBottom:"var(--space-2)"}}>الخطة الدراسية</h1>
        <p style={{font:"var(--type-body)",color:"var(--text-on-canvas-muted)",maxWidth:"60ch",marginBottom:"var(--space-8)"}}>
          يختار الطالب كلية واحدة إلزامية يصعد في مستوياتها الأربعة، وله أن يضيف كلية المهارات والقيادة اختيارية.
        </p>
        <Alert tone="info" title="كلية واحدة إلزامية" icon={<i data-lucide="info"></i>}>
          يختار الطالب كلية واحدة فقط كإلزامية ويصعد في مستوياتها، وكلية المهارات والقيادة اختيارية.
        </Alert>
        <div style={{display:"flex",flexDirection:"column",gap:"var(--space-4)",marginTop:"var(--space-8)"}}>
          {stages.map((s,i)=>(
            <DarkCard key={s.n} accent={s.state==="current"?"var(--tawr-yellow-500)":undefined} strong={s.state==="current"}
              style={{display:"grid",gridTemplateColumns:"88px 1fr auto",gap:"var(--space-5)",alignItems:"center"}}>
              <div style={{display:"grid",placeItems:"center",width:72,height:72,borderRadius:"var(--radius-md)",
                background:s.state==="open"?"rgba(0,0,0,.18)":"var(--tawr-teal-800)"}}>
                <span style={{font:"var(--fw-extrabold) 30px/1 var(--font-display)",color:s.state==="open"?"var(--text-on-canvas-muted)":"#fff"}}>{["١","٢","٣","٤"][i]}</span>
              </div>
              <div>
                <h3 style={{color:"var(--text-on-canvas)",marginBottom:4}}>{s.n}</h3>
                <p style={{font:"var(--type-body)",color:"var(--text-on-canvas-muted)",margin:0}}>{s.focus}</p>
              </div>
              <Badge tone={tone[s.state]} dot={s.state==="current"}>{label[s.state]}</Badge>
            </DarkCard>
          ))}
        </div>
        <DarkCard style={{marginTop:"var(--space-10)"}} padding="var(--space-8)">
          <h3 style={{color:"var(--text-on-canvas)",marginBottom:"var(--space-5)"}}>تقدّمك عبر الكليات</h3>
          <div style={{display:"flex",flexDirection:"column",gap:"var(--space-4)"}}>
            {colleges.map(c=>(
              <div key={c.id} style={{display:"grid",gridTemplateColumns:"200px 1fr 44px",alignItems:"center",gap:"var(--space-4)"}}>
                <span style={{font:"var(--type-body-strong)",color:"var(--text-on-canvas)"}}>{c.name}</span>
                <ProgressBar value={c.passed} max={4} color={c.color} height={10}/>
                <span style={{font:"var(--type-caption)",fontFamily:"var(--font-mono)",color:"var(--text-on-canvas-muted)",textAlign:"left"}}>{c.passed}/4</span>
              </div>
            ))}
          </div>
          <div style={{display:"flex",gap:"var(--space-2)",marginTop:"var(--space-6)",flexWrap:"wrap"}}>
            {levels.map(l=><LevelBadge key={l.key} level={l.key} size="sm"/>)}
          </div>
        </DarkCard>
        <div style={{marginTop:"var(--space-8)"}}>
          <Button size="lg" onClick={()=>go("signup")}>سجّل الآن</Button>
        </div>
      </main>
    </CanvasPage>
  );
}

Object.assign(window, { PlanScreen });
