const { Button, Input, Select, Tabs, Logo } = window.TawrUniversityDesignSystem_40b441;

/* شاشة تسجيل بعمودين — مبنية على هوية طور: خلفية الشيفرون، والتيل/الأصفر/المرجاني. */
function StepItem({ number, text, active, color }) {
  return (
    <div style={{display:"flex",alignItems:"center",gap:"var(--space-3)",padding:"var(--space-3) var(--space-4)",
      borderRadius:"var(--radius-pill)",
      background:active?"#fff":"rgba(22,39,47,.72)",
      border:active?"var(--stroke) solid #fff":"1px solid var(--border-canvas)",
      color:active?"var(--tawr-navy-800)":"var(--text-on-canvas)"}}>
      <span style={{width:26,height:26,borderRadius:"50%",flex:"0 0 auto",display:"grid",placeItems:"center",
        font:"var(--fw-bold) 12px/1 var(--font-mono)",
        background:active?(color||"var(--tawr-teal-600)"):"rgba(255,255,255,.1)",
        color:active?"#fff":"var(--text-on-canvas-muted)"}}>{number}</span>
      <span style={{font:"var(--type-body-strong)"}}>{text}</span>
    </div>
  );
}

function SignupScreen({ go }) {
  const [mode,setMode] = React.useState("login");
  const [reveal,setReveal] = React.useState(false);
  const [done,setDone] = React.useState(false);
  const isLogin = mode === "login";
  const dark = {"--text-strong":"var(--text-on-canvas)","--surface-card":"rgba(255,255,255,.06)","--surface-sunken":"rgba(0,0,0,.28)","--border-default":"var(--border-canvas)","--text-muted":"var(--text-on-canvas-muted)"};

  return (
    <div style={{display:"flex",height:"calc(100vh - 84px)",overflow:"hidden",background:"var(--surface-canvas)",padding:"var(--space-4)",gap:"var(--space-4)"}}>
      {/* العمود الأيمن (RTL: الأول) — الهوية */}
      <aside style={{position:"relative",width:"52%",flex:"0 0 52%",borderRadius:"var(--radius-2xl)",overflow:"hidden",
        display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"flex-start",
        padding:"var(--space-10) var(--space-12)",height:"100%",overflowY:"auto",
        boxShadow:"var(--shadow-lg)",background:"var(--tawr-navy-800)"}}>
        <CanvasBackdrop opacity={.75} width={330}/>
        <div aria-hidden="true" style={{position:"absolute",inset:0,left:-26,top:8,background:"linear-gradient(270deg,#0F0C08EB,rgba(22,39,47,.74) 55%,rgba(22,39,47,.32) 100%)"}}>
          <Logo src="../../assets/logo-wordmark-transparent.png" height={88} style={{objectFit:"contain",position:"absolute",left:444,top:6}}/>
        </div>
        <img src="../../assets/logo-chevron-mark.png" alt="" aria-hidden="true"
          style={{position:"absolute",insetInlineStart:"6%",bottom:"6%",width:"34%",opacity:.12,pointerEvents:"none"}}/>
        <div style={{position:"absolute",zIndex:1,width:"100%",maxWidth:340,left:189,top:207,marginBlock:"auto",flex:"0 0 auto",display:"flex",flexDirection:"column",gap:"var(--space-6)"}}>
          <div>
            <h2 style={{font:"var(--fw-extrabold) 38px/1.15 var(--font-display)",color:"var(--text-on-canvas)",whiteSpace:"nowrap"}}></h2>
            <p style={{font:"var(--type-body)",color:"var(--text-on-canvas-muted)",margin:"var(--space-3) 0 0"}}>
ادخل بحسابك، أو أنشئ حسابًا جديدًا في ثلاث خطوات.
            </p>
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:"var(--space-3)"}}>
            <StepItem number="١" text="سجّل بياناتك" active color="var(--tawr-teal-600)"/>
            <StepItem number="٢" text="اختر كليتك الإلزامية"/>
            <StepItem number="٣" text="أكمل ملفك الشخصي"/>
          </div>
        </div>
      </aside>

      {/* العمود الأيسر — النموذج */}
      <section style={{flex:1,minWidth:0,height:"100%",display:"flex",flexDirection:"column",alignItems:"center",
        padding:"var(--space-12) var(--space-10)",overflowY:"auto"}}>
        {done ? (
          <div style={{width:"100%",maxWidth:560,display:"flex",flexDirection:"column",gap:"var(--space-4)",alignItems:"flex-start"}}>
            <img src="../../assets/logo-chevron-mark.png" alt="" style={{height:44,width:"auto"}}/>
            <h1 style={{font:"var(--fw-extrabold) 30px/1.2 var(--font-display)",color:"var(--text-on-canvas)"}}>
              {isLogin ? "مرحبًا بك" : "وصل طلبك"}
            </h1>
            <p style={{font:"var(--type-body)",color:"var(--text-on-canvas-muted)",maxWidth:"44ch"}}>
              {isLogin ? "تم الدخول إلى حسابك." : "سيتواصل معك أحد المعلمين المشرفين لتأكيد المقعد قبل البداية."}
            </p>
            <Button variant="accent" onClick={()=>setDone(false)}>رجوع</Button>
          </div>
        ) : (
        <div style={{...dark,width:"100%",maxWidth:560,display:"flex",flexDirection:"column",gap:"var(--space-6)"}}>
          <div>
            <h1 style={{font:"var(--fw-extrabold) 30px/1.2 var(--font-display)",color:"var(--text-on-canvas)"}}>
              {isLogin ? "تسجيل الدخول" : "حساب جديد"}
            </h1>
            <p style={{font:"var(--type-body)",color:"#FACB62",margin:"var(--space-2) 0 0"}}>
              {isLogin ? "أدخل اسمك وكلمة المرور للمتابعة." : "أدخل بياناتك لإنشاء حسابك."}
            </p>
          </div>

          <div style={{"--tawr-teal-600":"#4EB9B6"}}>
          <Tabs value={mode} onChange={setMode} items={[{value:"login",label:"تسجيل الدخول"},{value:"signup",label:"حساب جديد"}]}/>
          </div>

          {isLogin ? (
            <React.Fragment>
              <div style={{"--text-strong":"#EE7C7D"}}>
                <Input label="الاسم" placeholder="اكتب اسمك" icon={<i data-lucide="user"></i>}/>
              </div>
              <div style={{position:"relative","--text-strong":"#EE7C7D"}}>
                <Input label="كلمة المرور" type={reveal?"text":"password"} placeholder="••••••••"/>
                <button type="button" onClick={()=>setReveal(r=>!r)} aria-label="إظهار كلمة المرور"
                  style={{position:"absolute",left:12,top:38,background:"transparent",border:"none",cursor:"pointer",
                    color:"var(--text-on-canvas-muted)",display:"grid",placeItems:"center",padding:6}}>
                  <i data-lucide={reveal?"eye-off":"eye"}></i>
                </button>
              </div>
              <Button size="lg" fullWidth onClick={()=>setDone(true)} style={{marginTop:"var(--space-2)",backgroundColor:"#4EB9B6"}}><span style={{color:"#26404D"}}>تسجيل الدخول</span></Button>
            </React.Fragment>
          ) : (
            <React.Fragment>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"var(--space-4)"}}>
                <Input label="الاسم الأول" placeholder="محمد"/>
                <Input label="اسم العائلة" placeholder="العتيبي"/>
              </div>
              <Input label="البريد الإلكتروني" type="email" placeholder="name@example.com" icon={<i data-lucide="mail"></i>}/>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"var(--space-4)"}}>
                <Input label="رقم الجوال" placeholder="05xxxxxxxx" icon={<i data-lucide="phone"></i>}/>
                <Select label="المرحلة" placeholder="اختر المرحلة" options={[{value:"1",label:"أول ثانوي"},{value:"2",label:"ثاني ثانوي"},{value:"3",label:"ثالث ثانوي"}]}/>
              </div>
              <div style={{position:"relative"}}>
                <Input label="كلمة المرور" type={reveal?"text":"password"} placeholder="••••••••" hint="ثمانية رموز على الأقل."/>
                <button type="button" onClick={()=>setReveal(r=>!r)} aria-label="إظهار كلمة المرور"
                  style={{position:"absolute",left:12,top:38,background:"transparent",border:"none",cursor:"pointer",
                    color:"var(--text-on-canvas-muted)",display:"grid",placeItems:"center",padding:6}}>
                  <i data-lucide={reveal?"eye-off":"eye"}></i>
                </button>
              </div>
              <Button size="lg" fullWidth onClick={()=>setDone(true)} style={{marginTop:"var(--space-2)"}}>أنشئ الحساب</Button>
            </React.Fragment>
          )}

          <p style={{font:"var(--type-body)",fontSize:"var(--fs-body-sm)",color:"var(--text-on-canvas-muted)",textAlign:"center",margin:0}}>
            {isLogin ? "ليس لديك حساب؟ " : "لديك حساب؟ "}
            <a href="#switch" onClick={e=>{e.preventDefault();setMode(isLogin?"signup":"login")}}
              style={{color:"#FACB62",borderBottom:"1px solid rgba(99,196,193,.4)"}}>
              {isLogin ? "أنشئ حسابًا" : "ادخل الآن"}
            </a>
          </p>
        </div>
        )}
      </section>
    </div>
  );
}

Object.assign(window, { SignupScreen, StepItem });
