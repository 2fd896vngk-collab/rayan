function SiteApp() {
  const [route,setRoute] = React.useState("home");
  const go = r => { setRoute(r); window.scrollTo({top:0}); };
  React.useEffect(()=>{ window.lucide && window.lucide.createIcons(); });
  const screens = { home:HomeScreen, plan:PlanScreen, attendance:AttendanceScreen, signup:SignupScreen, supervisor:SupervisorScreen };
  const Screen = screens[route] || HomeScreen;
  return (
    <div style={{minHeight:"100vh",display:"flex",flexDirection:"column"}}>
      <SiteHeader route={route} go={go}/>
      <div style={{flex:1}}><Screen go={go}/></div>
      <SiteFooter/>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<SiteApp/>);
