const { Button, StatTile, ProgressBar, Badge, LevelBadge, Logo } = window.TawrUniversityDesignSystem_40b441;

function Hero({ go }) {
  return (
    <section style={{position:"relative",overflow:"hidden"}}>
      <CanvasBackdrop/>
      <div style={{position:"relative",maxWidth:"var(--container-max)",margin:"0 auto",padding:"var(--space-12) var(--container-pad) var(--space-20)",display:"grid",gridTemplateColumns:"1.05fr .95fr",gap:"var(--space-12)",alignItems:"center"}}>
        <div>
          <h1 style={{display:"flex",alignItems:"flex-end",gap:"var(--space-3)",font:"var(--fw-extrabold) 64px/1 var(--font-display)",color:"var(--text-on-canvas)",margin:"0 0 var(--space-5)"}}>
            <span style={{lineHeight:1}}>جامعة</span>
            <Logo src="../../assets/logo-wordmark-transparent.png" height={104} alt="طوّر" style={{marginBottom:-14}}/>
          </h1>
          <p style={{font:"var(--fs-body)/1.75 var(--font-text)",color:"var(--text-on-canvas-muted)",maxWidth:"52ch",margin:"var(--space-6) 0 var(--space-10)"}}>
            <span style={{color:"#FFFFFF"}}>جامعة تعليمية تنافسية تتكوّن من عدة كليات، يتدرّج الطالب فيها عبر درجات أكاديمية: الدبلوم، البكالوريوس، الماجستير، والدكتوراه</span>
          </p>
          <div style={{display:"flex",gap:"var(--space-3)"}}>
            <Button size="lg" variant="primary" onClick={()=>go("signup")} style={{backgroundColor:"#FACB62"}}><span style={{color:"#2F4D5B"}}>ابدأ التسجيل</span></Button>
            <Button size="lg" variant="accent" onClick={()=>go("plan")} style={{backgroundColor:"#EE7C7D"}}><span style={{color:"#FFFFFF"}}>اطّلع على الخطة</span></Button>
          </div>
        </div>
        <div/>
      </div>
    </section>
  );
}

function CollegeTile({ c, go, enrolled }) {
  const [hover,setHover] = React.useState(false);
  return (
    <div onClick={enrolled?()=>go("plan"):undefined}
      onMouseEnter={()=>enrolled&&setHover(true)} onMouseLeave={()=>setHover(false)}
      style={{position:"relative",overflow:"hidden",cursor:enrolled?"pointer":"default",borderRadius:"var(--radius-card)",
        padding:"var(--card-pad)",background:hover?"var(--surface-canvas-card-strong)":"var(--surface-canvas-card)",
        border:"1px solid var(--border-canvas)",transform:hover?"translateY(var(--hover-lift))":"none",
        transition:"background-color var(--dur-base) var(--ease-standard),transform var(--dur-base) var(--ease-standard)",
        display:"flex",flexDirection:"column",gap:"var(--space-3)"}}>
      <span style={{position:"absolute",insetInline:0,top:0,height:4,background:c.color}}/>
      <img src="../../assets/logo-chevron-mark.png" alt="" style={{position:"absolute",insetInlineStart:-18,bottom:-14,width:120,opacity:.1,pointerEvents:"none"}}/>
      <div style={{display:"flex",alignItems:"center",gap:"var(--space-3)"}}>
        <span style={{width:46,height:46,borderRadius:"var(--radius-md)",background:c.color,color:"var(--tawr-navy-800)",display:"grid",placeItems:"center",flex:"0 0 auto"}}>
          <i data-lucide={c.icon}></i>
        </span>
        <h3 style={{margin:0,color:"var(--text-on-canvas)",font:"var(--type-card-title)",flex:1}}>{c.name}</h3>
        {enrolled
          ? <span style={{font:"var(--type-caption)",fontWeight:"var(--fw-bold)",color:"var(--tawr-navy-800)",background:"var(--tawr-teal-500)",borderRadius:"var(--radius-pill)",padding:"3px 10px",whiteSpace:"nowrap"}}>كليتي</span>
          : c.optional && <span style={{font:"var(--type-caption)",fontWeight:"var(--fw-bold)",color:"var(--tawr-yellow-500)",border:"1px solid var(--tawr-yellow-500)",borderRadius:"var(--radius-pill)",padding:"3px 10px",whiteSpace:"nowrap"}}>اختيارية</span>}
      </div>
      <p style={{font:"var(--type-body)",color:"var(--text-on-canvas-muted)",margin:0}}>{c.desc}</p>
      <div style={{marginTop:"auto",display:"flex",flexDirection:"column",gap:"var(--space-2)"}}>
        <div style={{display:"flex",justifyContent:"space-between",font:"var(--type-caption)",color:"var(--text-on-canvas-muted)"}}>
          <span>المستويات المجتازة</span>
          <span style={{fontFamily:"var(--font-mono)"}}>{c.passed}/4</span>
        </div>
        <ProgressBar value={c.passed} max={4} color={c.color} height={8}/>
      </div>
    </div>
  );
}

function HomeScreen({ go }) {
  const { colleges, levels } = window.TAWR;
  const enrolledId = "tech"; /* الكلية التي يدرسها الطالب */
  return (
    <CanvasPage>
      <Hero go={go}/>
      <section style={{maxWidth:"var(--container-max)",margin:"0 auto",padding:"0 var(--container-pad)",display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:"var(--gutter)"}}>
        <StatTile tone="brand" background="#4EB9B6" value="٥" label="كليات" sub="يختار الطالب كلية واحدة إلزاميًا"/>
        <StatTile tone="accent" background="#FACB62" valueColor="#26404D" value="٤" label="مستويات" sub="من الدبلوم إلى الدكتوراه"/>
        <StatTile tone="ink" background="#EE7C7D" subColor="#FFFFFF" value="١" label="كلية إلزامية" sub="يختارها الطالب بنفسه"/>
        <StatTile tone="ink" background="#2F4D5B" subColor="#FFFFFF" value="١" label="كلية اختيارية" sub="المهارات والقيادة"/>
      </section>

      <section style={{maxWidth:"var(--container-max)",margin:"0 auto",padding:"var(--space-20) var(--container-pad)"}}>
        <SectionHead title="الكليات الخمس"
          sub="كليتك مفتوحة للدخول إلى خطتها، وبقية الكليات للعرض فقط."/>
        <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:"var(--gutter)"}}>
          {colleges.map(c=><CollegeTile key={c.id} c={c} go={go} enrolled={c.id===enrolledId}/>)}
        </div>
      </section>

      <section style={{maxWidth:"var(--container-max)",margin:"0 auto",padding:"0 var(--container-pad) var(--space-20)"}}>
        <SectionHead title="المستويات الأربعة" sub="أسماء الدرجات الجامعية تُستعمل كما هي: كل مستوى يُجتاز باختبار وإشراف معلم."/>
        <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:"var(--gutter)"}}>
          {levels.map((l,i)=>(
            <DarkCard key={l.key} style={{display:"flex",flexDirection:"column",gap:"var(--space-3)"}}>
              <LevelBadge level={l.key} showNumber color={l.key==="diploma"?"#99ACB4":l.key==="phd"?"#EE7C7D":undefined} textColor={l.key==="diploma"?"#E4EBEE":undefined} numberColor={l.key==="diploma"?"#FFFFFF":undefined}/>
              <p style={{font:"var(--type-body)",color:"var(--text-on-canvas-muted)",margin:0}}>
                {["يُفتح للجميع عند بداية الكلية.","يتطلب اجتياز الدبلوم في الكلية نفسها.","مسألة متخصصة داخل الكلية.","مشروع تخرّج بإشراف معلم."][i]}
              </p>
              <img src="../../assets/logo-chevron-mark.png" alt="" style={{position:"absolute",insetInlineStart:-18,bottom:-14,width:120,opacity:.1,pointerEvents:"none"}}/>
            </DarkCard>
          ))}
        </div>
      </section>

    </CanvasPage>
  );
}

Object.assign(window, { HomeScreen });
