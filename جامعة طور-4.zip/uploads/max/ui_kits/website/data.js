window.TAWR = {
  colleges: [
    { id:"sharia",  name:"كلية الشريعة",           color:"var(--faculty-sharia)", icon:"book-marked",     passed:1, desc:"أصول الفقه والعبادات وأحكام المعاملات." },
    { id:"seerah",  name:"كلية السيرة والتاريخ",   color:"var(--faculty-seerah)", icon:"landmark",  passed:2, desc:"السيرة النبوية وتاريخ الأمة ورجالها." },
    { id:"quran",   name:"كلية القرآن وعلومه",     color:"var(--faculty-quran)",  icon:"book-open", passed:1, desc:"الحفظ والتجويد والتفسير وعلوم القرآن." },
    { id:"tech",    name:"كلية التقنية",            color:"var(--faculty-tech)",   icon:"cpu",       passed:2, desc:"البرمجة والتصميم والأمن الرقمي." },
    { id:"skills",  name:"كلية المهارات والقيادة",  color:"var(--faculty-skills)", icon:"users",     passed:3, desc:"القيادة والعمل الجماعي وإدارة المبادرات.", optional:true }
  ],
  levels: [
    { key:"diploma",  label:"دبلوم" },
    { key:"bachelor", label:"بكالوريوس" },
    { key:"master",   label:"ماجستير" },
    { key:"phd",      label:"دكتوراه" }
  ],
  stages: [
    { n:"الدبلوم",     focus:"مدخل الكلية ومصطلحاتها الأساسية", state:"passed" },
    { n:"البكالوريوس", focus:"التوسّع في الأصول وورشة عملية", state:"passed" },
    { n:"الماجستير",   focus:"مسألة متخصصة وبحث قصير", state:"current" },
    { n:"الدكتوراه",   focus:"مشروع التخرّج بإشراف معلم", state:"open" }
  ]
};
