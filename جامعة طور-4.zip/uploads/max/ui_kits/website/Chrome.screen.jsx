const { Button, IconButton, Logo } = window.TawrUniversityDesignSystem_40b441;

/* Every surface sits on the brand's navy canvas with the chevron field behind it. */
function CanvasBackdrop({ opacity=1, width=470 }) {
  return <div aria-hidden="true" style={{position:"absolute",left:0,top:0,bottom:0,width,opacity,pointerEvents:"none",
    backgroundImage:"url('../../assets/pattern-chevrons-scatter.png')",backgroundSize:width+"px auto",
    backgroundRepeat:"repeat-y",backgroundPosition:"left top",
    maskImage:"linear-gradient(to right,#000 0%,#000 55%,transparent 100%)",
    WebkitMaskImage:"linear-gradient(to right,#000 0%,#000 55%,transparent 100%)"}}/>;
}

function SiteHeader({ route, go }) {
  const nav = [["home","الرئيسية"],["plan","الخطة"],["attendance","التحضير"],["signup","تسجيل الدخول"]];
  return (
    <header style={{position:"sticky",top:0,zIndex:20,background:"rgba(30,53,64,.9)",backdropFilter:"var(--blur-glass)",WebkitBackdropFilter:"var(--blur-glass)",borderBottom:"1px solid var(--border-canvas)"}}>
      <div style={{maxWidth:"var(--container-max)",margin:"0 auto",padding:"0 var(--container-pad)",height:84,display:"flex",alignItems:"center",gap:"var(--space-8)"}}>
        <a href="#home" onClick={e=>{e.preventDefault();go("home")}} style={{border:"none",display:"flex",alignItems:"center"}}>
          <Logo src="../../assets/logo-wordmark-transparent.png" height={52}/>
        </a>
        <nav style={{display:"flex",gap:"var(--space-6)",flex:1}}>
          {nav.map(([k,l])=>(
            <a key={k} href={"#"+k} onClick={e=>{e.preventDefault();go(k)}}
              style={{border:"none",font:route===k?"var(--fw-bold) var(--fs-body-sm)/1 var(--font-text)":"var(--fw-medium) var(--fs-body-sm)/1 var(--font-text)",
                color:route===k?"var(--tawr-teal-500)":"var(--text-on-canvas-muted)",paddingBottom:4,
                borderBottom:route===k?"var(--stroke) solid var(--tawr-teal-500)":"var(--stroke) solid transparent"}}>{l}</a>
          ))}
        </nav>
        <IconButton tone="glass" label="بحث" icon={<i data-lucide="search"></i>}/>
        <Button variant="primary" size="sm" onClick={()=>go("signup")} style={{backgroundColor:"#FACB62"}}><span style={{color:"#26404D"}}>ابدأ التسجيل</span></Button>
      </div>
    </header>
  );
}

function SiteFooter() {
  return (
    <footer style={{position:"relative",overflow:"hidden",background:"var(--surface-canvas)",borderTop:"1px solid var(--border-canvas)",color:"var(--text-on-canvas-muted)",padding:"var(--space-16) 0 var(--space-8)"}}>
      <CanvasBackdrop opacity={.45} width={380}/>
      <div style={{position:"relative",maxWidth:"var(--container-max)",margin:"0 auto",padding:"0 var(--container-pad)",display:"grid",gridTemplateColumns:"1.4fr 1fr 1fr",gap:"var(--space-12)"}}>
        <div>
          <Logo src="../../assets/logo-wordmark-transparent.png" height={64}/>
          <p style={{font:"var(--type-body)",marginTop:"var(--space-5)",maxWidth:"38ch"}}>
            جامعة تعليمية تنافسية تتكوّن من عدة كليات، يتدرّج الطالب فيها عبر درجات أكاديمية: الدبلوم، البكالوريوس، الماجستير، والدكتوراه
          </p>
        </div>
        <div>
          <h4 style={{color:"var(--text-on-canvas)",font:"var(--type-label)",marginBottom:"var(--space-3)"}}>الكليات</h4>
          <ul style={{listStyle:"none",padding:0,margin:0,display:"flex",flexDirection:"column",gap:"var(--space-2)",fontSize:"var(--fs-body-sm)"}}>
            {window.TAWR.colleges.map(c=><li key={c.id}>{c.name}</li>)}
          </ul>
        </div>
        <div>
          <h4 style={{color:"var(--text-on-canvas)",font:"var(--type-label)",marginBottom:"var(--space-3)"}}>المستويات</h4>
          <ul style={{listStyle:"none",padding:0,margin:0,display:"flex",flexDirection:"column",gap:"var(--space-2)",fontSize:"var(--fs-body-sm)"}}>
            {window.TAWR.levels.map(l=><li key={l.key}>{l.label}</li>)}
          </ul>
        </div>
      </div>
      <div style={{position:"relative",maxWidth:"var(--container-max)",margin:"var(--space-10) auto 0",padding:"var(--space-6) var(--container-pad) 0",borderTop:"1px solid var(--border-canvas)",display:"flex",justifyContent:"space-between",fontSize:"var(--fs-caption)"}}>
        <span>جامعة طور — جميع الحقوق محفوظة</span>
        <span style={{color:"var(--tawr-teal-500)",fontWeight:"var(--fw-bold)"}}></span>
      </div>
    </footer>
  );
}

/* Shared page shell: navy canvas + chevron field, used by every screen. */
function CanvasPage({ children }) {
  return <div style={{position:"relative",background:"var(--surface-canvas)",minHeight:"100%",overflow:"hidden"}}>
    {children}
  </div>;
}

function DarkCard({ children, accent, padding="var(--card-pad)", strong, style, ...rest }) {
  return <div style={{position:"relative",overflow:"hidden",background:strong?"var(--surface-canvas-card-strong)":"var(--surface-canvas-card)",
    border:"1px solid var(--border-canvas)",borderRadius:"var(--radius-card)",padding,
    backdropFilter:"blur(6px)",WebkitBackdropFilter:"blur(6px)",...style}} {...rest}>
    {accent && <span style={{position:"absolute",insetInline:0,top:0,height:4,background:accent}}/>}
    {children}
  </div>;
}

function SectionHead({ title, sub, action }) {
  return <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-end",gap:"var(--space-8)",marginBottom:"var(--space-8)"}}>
    <div>
      <h2 style={{color:"var(--text-on-canvas)"}}>{title}</h2>
      {sub && <p style={{font:"var(--type-body)",color:"var(--text-on-canvas-muted)",margin:"var(--space-2) 0 0",maxWidth:"56ch"}}>{sub}</p>}
    </div>
    {action}
  </div>;
}

Object.assign(window, { SiteHeader, SiteFooter, CanvasPage, CanvasBackdrop, DarkCard, SectionHead });
