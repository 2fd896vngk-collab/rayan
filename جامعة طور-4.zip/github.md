repo: 2fd896vngk-collab/cl
branch: main

## Last sync
date: 2026-08-26T10:52:03Z
### Updated in this project
- ربط المستودع بالمشروع (لا تغييرات مستوردة بعد)

## Screen map
| Project screen | Repo files |
| --- | --- |
| Tawr-Platform.dc.html (المنصة كاملة) | tawr-university-design-system/project/ (نظام التصميم المصدر) |
